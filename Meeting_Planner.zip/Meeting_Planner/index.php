<?php
// index.php
session_start();
require_once __DIR__ . '/includes/config.php'; // ✅ using your existing PDO config

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim($_POST['email']);
    $password = $_POST['password'];

    try {
        // ✅ Use prepared statement with named placeholder
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // ✅ Simple password comparison (same as your DB)
            if ($password === $user['password']) {

                $_SESSION['user'] = [
                    'id'    => $user['id'],
                    'name'  => $user['first_name'] . ' ' . $user['last_name'],
                    'email' => $user['email'],
                    'role'  => $user['role']
                ];

                // ✅ Redirect using header (no echo script)
                header("Location: dashboard.php");
                exit;

            } else {
                $error = "Invalid password!";
            }
        } else {
            $error = "User not found!";
        }
    } catch (PDOException $e) {
        $error = "Database error: " . htmlspecialchars($e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login | Meeting & Task Planner</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            min-height: 100vh;
            font-family: "Inter", system-ui, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
            position: relative;
            overflow: hidden;
        }

        body::before,
        body::after {
            content: "";
            position: absolute;
            width: 420px;
            height: 420px;
            background: linear-gradient(135deg, #7c3aed, #4f46e5);
            opacity: 0.35;
            z-index: 0;
        }

        body::before {
            top: -120px;
            left: -120px;
            transform: rotate(45deg);
        }

        body::after {
            bottom: -120px;
            right: -120px;
            transform: rotate(45deg);
        }

        .login-wrapper {
            background: #ffffff;
            width: 100%;
            max-width: 900px;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 35px 90px rgba(0,0,0,0.45);
            position: relative;
            z-index: 1;
            margin: auto;
        }

        .login-wrapper.row {
            margin-left: 0;
            margin-right: 0;
        }

        .login-left {
            padding: 45px;
        }

        .login-left h2 {
            font-size: 26px;
            font-weight: 600;
            margin-bottom: 6px;
        }

        .login-left p {
            color: #6b7280;
            margin-bottom: 25px;
            font-size: 14px;
        }

        .form-label {
            font-weight: 500;
            font-size: 14px;
        }

        .form-control {
            padding: 12px 14px;
            border-radius: 10px;
            border: 1px solid #d1d5db;
            font-size: 14px;
        }

        .btn-login {
            background: #8478FC;
            border: none;
            padding: 12px;
            border-radius: 10px;
            color: #ffffff;
            font-size: 15px;
            font-weight: 500;
            transition: all 0.25s ease;
        }

        .btn-login:hover {
            background: #6f63e6;
        }

        .login-right {
            background: #f8fafc;
            padding: 40px;
            text-align: center;
        }

        .login-right img {
            max-width: 85%;
            margin-bottom: 18px;
        }

        .login-right h4 {
            font-weight: 600;
            margin-bottom: 8px;
        }

        .login-right p {
            font-size: 14px;
            color: #6b7280;
        }

        .create-account {
            color: #8478FC;
            font-weight: 600;
            text-decoration: none;
        }

        .create-account:hover {
            color: #6f63e6;
        }

        @media (max-width: 768px) {
            .login-right {
                display: none;
            }
        }
        /* ===== HOME BUTTON (TOP RIGHT) ===== */
.home-btn {
    position: fixed;
    top: 20px;
    right: 20px;
    background: #8478FC;
    color: #ffffff;
    padding: 10px 20px;
    border-radius: 30px;
    font-weight: 600;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    box-shadow: 0 12px 30px rgba(132, 120, 252, 0.45);
    transition: all 0.25s ease;
    z-index: 10;
}

.home-btn:hover {
    background: #6f63e6;
    transform: translateY(-2px);
}

/* Responsive tweak */
@media (max-width: 576px) {
    .home-btn {
        padding: 8px 16px;
        font-size: 14px;
        top: 14px;
        right: 14px;
    }
}
    </style>
</head>

<body>

<a href="home.php" class="home-btn">
    ← Home
</a>

<div class="login-wrapper row g-0">

    <!-- LEFT -->
    <div class="col-md-6 login-left">
        <h2>Let’s get you signed in</h2>
        <p>Enter your details to continue</p>

        <?php if ($success): ?>
            <div class="alert alert-success"><?= $success ?></div>
            <script>
                setTimeout(() => window.location.href = "dashboard.php", 1500);
            </script>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Email*</label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Password*</label>
                <input type="password" name="password" class="form-control" required>
            </div>

            <button class="btn btn-login w-100">Log In</button>
        </form>

        <p class="text-center mt-4 small">
            New here?
            <a href="register.php" class="create-account">Create an account</a>
        </p>
    </div>

    <!-- RIGHT -->
    <div class="col-md-6 login-right">
        <img src="https://img.freepik.com/free-vector/schedule-planning-concept-illustration_114360-1531.jpg" alt="">
        <h4>Welcome to Meeting & Task Planner</h4>
        <p>
            Organize meetings, manage tasks, track attendance,
            and collaborate efficiently — all in one smart platform.
        </p>
    </div>

</div>

</body>
</html>