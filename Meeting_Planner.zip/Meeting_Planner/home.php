<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Home | Meeting & Task Planner</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

<style>
html { scroll-behavior: smooth; }

body {
  height: 100vh;
  margin: 0;
  background:
    radial-gradient(circle at top left, #7c6cf9, #1f1b4d 60%, #0b0a2a);
  font-family: "Inter", system-ui, sans-serif;
  overflow: hidden;
  color: white;
  position: relative;
}

/* ===== ANIMATED GRID ===== */
.bg-lines {
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    135deg,
    rgba(255,255,255,.04) 0,
    rgba(255,255,255,.04) 1px,
    transparent 1px,
    transparent 60px
  );
  animation: moveLines 30s linear infinite;
  z-index: 0;
}
@keyframes moveLines {
  to { background-position: 600px 600px; }
}

/* ===== NAVBAR (UPDATED) ===== */
.navbar {
  backdrop-filter: blur(14px);
  background: rgba(12, 10, 45, 0.75);
  box-shadow: 0 10px 40px rgba(0,0,0,.45);
  padding: 14px 0;
  z-index: 10;
}

.navbar-brand {
  font-weight: 800;
  font-size: 1.3rem;
  color: #fff !important;
  display: flex;
  align-items: center;
  gap: 10px;
}

.navbar-brand i {
  font-size: 1.4rem;
}

/* Navbar Buttons */
.nav-btn {
  padding: 10px 22px;
  border-radius: 30px;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 8px;
  border: none;
}

.btn-login {
  background: rgba(255,255,255,.12);
  color: #fff;
}

.btn-login:hover {
  background: rgba(255,255,255,.2);
}

.btn-register {
  background: linear-gradient(135deg, #8b7cff, #a99cff);
  color: #fff;
}

.btn-register:hover {
  opacity: .9;
}

/* ===== HERO ===== */
.hero {
  height: 100vh;
  display: flex;
  align-items: center;
  position: relative;
  z-index: 2;
  padding-top: 90px;
}

/* ===== GLASS CARD ===== */
.hero-card {
  background: rgba(255,255,255,.08);
  backdrop-filter: blur(18px);
  border-radius: 26px;
  padding: 3rem;
  box-shadow:
    0 30px 80px rgba(0,0,0,.45),
    inset 0 1px 0 rgba(255,255,255,.2);
  animation: fadeUp 1s ease forwards;
}

.hero h1 {
  font-weight: 800;
  letter-spacing: .5px;
}

.hero p {
  font-size: 1.05rem;
  opacity: .9;
}

/* ===== CTA BUTTON ===== */
.btn-cta {
  background: linear-gradient(135deg,#ffffff,#dcd7ff);
  color: #2b266b;
  font-weight: 700;
  border-radius: 40px;
  padding: 14px 34px;
  border: none;
  box-shadow: 0 15px 40px rgba(255,255,255,.25);
  transition: all .35s ease;
}
.btn-cta:hover {
  transform: translateY(-4px) scale(1.05);
  box-shadow: 0 25px 60px rgba(255,255,255,.45);
}

/* ===== QUOTE ===== */
.quote {
  font-style: italic;
  opacity: .85;
  margin-top: 1rem;
  transition: opacity .4s ease;
}

/* ===== IMAGE ===== */
.illustration-wrapper {
  position: relative;
}
.illustration-wrapper::before {
  content:"";
  position:absolute;
  inset: -80px;
  background: radial-gradient(circle, rgba(124,108,249,.45), transparent 70%);
  filter: blur(35px);
  z-index:0;
}
.illustration {
  position: relative;
  z-index: 1;
  max-width: 420px;
  animation: floatImg 6s ease-in-out infinite;
}

@keyframes floatImg {
  0%,100% { transform: translateY(0); }
  50% { transform: translateY(-14px); }
}

@keyframes fadeUp {
  from { opacity: 0; transform: translateY(40px); }
  to { opacity: 1; transform: translateY(0); }
}

@media(max-width:768px){
  .hero-card { padding: 2rem; text-align:center; }
  .illustration { max-width: 300px; margin-top:2rem; }
}
</style>
</head>

<body>

<div class="bg-lines"></div>

<!-- NAVBAR -->
<nav class="navbar fixed-top">
  <div class="container px-5 d-flex align-items-center">
    <a class="navbar-brand" href="home.php">
      <i class="bi bi-calendar-event"></i>
      Meeting Planner
    </a>

    <div class="ms-auto d-flex gap-3">
      <a href="index.php" class="nav-btn btn-login">
        <i class="bi bi-box-arrow-in-right"></i> Login
      </a>
      <a href="register.php" class="nav-btn btn-register">
        <i class="bi bi-person-plus"></i> Register
      </a>
    </div>
  </div>
</nav>

<!-- HERO -->
<section class="hero">
  <div class="container">
    <div class="row align-items-center">

      <div class="col-md-6">
        <div class="hero-card">
          <small class="text-uppercase opacity-75">Do you need any help?</small>
          <h1 class="mt-3">Smart Meetings.<br>Powerful Teams.</h1>
          <p class="mt-3">
            Schedule meetings, manage tasks, track attendance,
            and collaborate across departments with ease.
          </p>
          <p class="quote" id="quote">“Well-planned meetings lead to powerful results.”</p>
          <a href="register.php" class="btn btn-cta mt-4">Get Started →</a>
        </div>
      </div>

      <div class="col-md-6 text-center">
        <div class="illustration-wrapper">
          <img src="uploads/meeting.png" class="illustration img-fluid" alt="Meeting">
        </div>
      </div>

    </div>
  </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const quotes = [
  "Well-planned meetings lead to powerful results.",
  "Clear tasks create confident teams.",
  "Plan smart. Execute better. Achieve more."
];
let i = 0;
setInterval(() => {
  i = (i + 1) % quotes.length;
  const q = document.getElementById("quote");
  q.style.opacity = 0;
  setTimeout(() => {
    q.innerText = "“" + quotes[i] + "”";
    q.style.opacity = 1;
  }, 400);
}, 4000);
</script>

</body>
</html>