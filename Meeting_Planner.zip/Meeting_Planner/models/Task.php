<?php
class Task {
    public static function all(PDO $pdo): array {
        try {
            // Adjust column if your tasks table uses 'title' instead of 'task_title'
            $stmt = $pdo->query("SELECT id, title AS task_title FROM tasks ORDER BY id DESC");
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log($e->getMessage());
            return [];
        }
    }
}
