<?php
class Meeting {
    public static function all(PDO $pdo): array {
        $stmt = $pdo->query("SELECT id, title FROM meetings ORDER BY id DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
