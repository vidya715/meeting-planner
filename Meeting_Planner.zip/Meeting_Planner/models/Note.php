<?php
class Note {
    public static function all(PDO $pdo): array {
        $sql = "
            SELECT n.*, 
                   m.title AS meeting_title,
                   u.name AS created_by_name
            FROM notes n
            JOIN meetings m ON m.id = n.meeting_id
            JOIN users u ON u.id = n.created_by
            ORDER BY n.id DESC
        ";
        $stmt = $pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function create(PDO $pdo, array $data): bool {
        $sql = "
            INSERT INTO notes (meeting_id, title, description, department, created_by, created_at)
            VALUES (:meeting_id, :title, :description, :department, :created_by, NOW())
        ";
        $stmt = $pdo->prepare($sql);
        return $stmt->execute([
            ':meeting_id' => $data['meeting_id'],
            ':title'      => $data['title'],
            ':description'=> $data['description'],
            ':department' => $data['department'],
            ':created_by' => $data['created_by']
        ]);
    }

    public static function update(PDO $pdo, int $id, array $data): bool {
        $sql = "
            UPDATE notes
            SET meeting_id = :meeting_id,
                title = :title,
                description = :description,
                department = :department
            WHERE id = :id
        ";
        $stmt = $pdo->prepare($sql);
        return $stmt->execute([
            ':meeting_id' => $data['meeting_id'],
            ':title'      => $data['title'],
            ':description'=> $data['description'],
            ':department' => $data['department'],
            ':id'         => $id
        ]);
    }

    public static function delete(PDO $pdo, int $id): bool {
        $stmt = $pdo->prepare("DELETE FROM notes WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }
}
