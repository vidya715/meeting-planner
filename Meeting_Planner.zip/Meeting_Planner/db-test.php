<?php
require_once __DIR__ . '/config/db.php';

echo "<pre>";

try {
    // Basic connectivity test
    echo "✅ Connected to database\n";

    // Server info
    echo "Server: " . $pdo->getAttribute(PDO::ATTR_SERVER_VERSION) . "\n";

    // Test simple query
    $stmt = $pdo->query("SELECT DATABASE()");
    echo "Database: " . $stmt->fetchColumn() . "\n";

    // Test table access
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    echo "Users count: " . $stmt->fetchColumn() . "\n";

    echo "📅 MEETINGS\n";
    echo "-------------------------\n";

    $stmt = $pdo->query("SELECT * FROM meetings ORDER BY id DESC LIMIT 20");
    $meetings = $stmt->fetchAll();

    if (empty($meetings)) {
        echo "No meetings found.\n";
    } else {
        foreach ($meetings as $m) {
            echo "ID: {$m['id']}\n";
            echo "Title: " . ($m['title'] ?? 'N/A') . "\n";
            echo "Date: " . ($m['meeting_date'] ?? 'N/A') . "\n";
            echo "Status: " . ($m['status'] ?? 'N/A') . "\n";
            echo "-------------------------\n";
        }
    }

} catch (Throwable $e) {
    echo "❌ DB TEST FAILED\n";
    echo $e->getMessage();
}

echo "</pre>";