<?php
header("Content-Type: application/json");
require_once "../includes/config.php";

$data = json_decode(file_get_contents("php://input"), true);
if (!$data) {
    echo json_encode(["success" => false, "error" => "Invalid data"]);
    exit;
}

$taskId = (int)($data['taskId'] ?? 0);
$status = trim($data['status'] ?? '');
$notes = trim($data['progress_notes'] ?? '');
$updatedBy = (int)($data['updatedBy'] ?? 0);

if (!$taskId || !$status) {
    echo json_encode(["success" => false, "error" => "Missing required fields"]);
    exit;
}

try {
    // Insert a new update
    $stmt = $pdo->prepare("
        INSERT INTO task_updates (task_id, status, progress_notes, updated_by, updated_on)
        VALUES (?, ?, ?, ?, NOW())
    ");
    $stmt->execute([$taskId, $status, $notes, $updatedBy]);

    // Sync task main table
  // ✅ Only update status (no 'last_updated' column)
$pdo->prepare("UPDATE tasks SET status = ? WHERE id = ?")
    ->execute([$status, $taskId]);


    echo json_encode(["success" => true]);
} catch (PDOException $e) {
    echo json_encode(["success" => false, "error" => $e->getMessage()]);
}
?>
