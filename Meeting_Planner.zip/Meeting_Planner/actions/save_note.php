<?php
require __DIR__ . '/../includes/config.php';
session_start();
if($_SERVER['REQUEST_METHOD']!=='POST'){ header("Location: ../pages/meeting_notes.php"); exit; }
$mid=(int)($_POST['meeting_id']??0);
$content=trim($_POST['content']??'');
$uid = $_SESSION['user']['id']??null;
if($mid && $content!==''){
  if($uid){
    $s=$conn->prepare("INSERT INTO notes(meeting_id,user_id,content,created_at) VALUES(?,?,?,NOW())");
    $s->bind_param("iis",$mid,$uid,$content);
  }else{
    $s=$conn->prepare("INSERT INTO notes(meeting_id,content,created_at) VALUES(?,?,NOW())");
    $s->bind_param("is",$mid,$content);
  }
  $s->execute();
}
header("Location: ../pages/meeting_notes.php?meeting_id=".$mid);
