<?php
require '../includes/config.php'; 
require '../models/Note.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $noteId = isset($_POST['note_id']) ? (int)$_POST['note_id'] : 0;

    $data = [
        'meeting_id'  => (int)($_POST['meeting_id'] ?? 0),
        'title'       => trim($_POST['title'] ?? ''),
        'description' => trim($_POST['description'] ?? ''),
        'department'  => trim($_POST['department'] ?? ''),
        'created_by'  => 1 // ✅ ensure this user exists in your 'users' table
    ];

    if ($action === 'add') {
        Note::create($pdo, $data);
    } elseif ($action === 'update' && $noteId > 0) {
        Note::update($pdo, $noteId, $data);
    } elseif ($action === 'delete' && $noteId > 0) {
        Note::delete($pdo, $noteId);
    }

    header("Location: ../pages/mom_notes.php");
    exit;
}
?>
