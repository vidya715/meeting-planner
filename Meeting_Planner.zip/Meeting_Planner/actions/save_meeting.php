<?php
require __DIR__ . '/../includes/config.php';
session_start();

/* ===============================
   ALLOW ONLY POST
   =============================== */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../pages/meeting_create.php");
    exit;
}

/* ===============================
   SANITIZE INPUT
   =============================== */
$title         = trim($_POST['title'] ?? '');
$meeting_date  = $_POST['meeting_date'] ?? '';
$meeting_time  = $_POST['meeting_time'] ?? '';
$duration      = (int)($_POST['duration'] ?? 0);
$mode          = $_POST['mode'] ?? 'ONLINE';
$location      = trim($_POST['location'] ?? '');
$department    = trim($_POST['department'] ?? '');
$agenda        = trim($_POST['agenda'] ?? '');
$attendees     = $_POST['attendees'] ?? [];

/* ===============================
   VALIDATION
   =============================== */
if ($title === '' || $meeting_date === '' || $meeting_time === '') {
    die("⚠️ Missing required fields.");
}

/* ===============================
   FILE UPLOAD (OPTIONAL)
   =============================== */
$file_path = null;

if (!empty($_FILES['file']['name'])) {

    $allowed = ['pdf','jpg','jpeg','png','doc','docx','txt'];
    $file_name = basename($_FILES['file']['name']);
    $ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

    if (in_array($ext, $allowed)) {

        $upload_dir = __DIR__ . '/../uploads/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $safe_name = time() . '_' . preg_replace("/[^a-zA-Z0-9_\.-]/", "_", $file_name);
        $upload_path = $upload_dir . $safe_name;

        if (move_uploaded_file($_FILES['file']['tmp_name'], $upload_path)) {
            $file_path = 'uploads/' . $safe_name;
        }
    }
}

/* ===============================
   INSERT MEETING (PDO)
   =============================== */
$sql = "
INSERT INTO meetings
(title, meeting_date, meeting_time, duration, mode, location, department, agenda, file_path, created_at)
VALUES
(:title, :meeting_date, :meeting_time, :duration, :mode, :location, :department, :agenda, :file_path, NOW())
";

$stmt = $pdo->prepare($sql);
$stmt->execute([
    ':title'        => $title,
    ':meeting_date' => $meeting_date,
    ':meeting_time' => $meeting_time,
    ':duration'     => $duration,
    ':mode'         => $mode,
    ':location'     => $location,
    ':department'   => $department,
    ':agenda'       => $agenda,
    ':file_path'    => $file_path
]);

$meeting_id = $pdo->lastInsertId();

/* ===============================
   INSERT ATTENDEES (PDO)
   =============================== */
if (!empty($attendees)) {
    $att_sql = "
        INSERT INTO meeting_attendees (meeting_id, user_id)
        VALUES (:meeting_id, :user_id)
    ";
    $att_stmt = $pdo->prepare($att_sql);

    foreach ($attendees as $user_id) {
        $att_stmt->execute([
            ':meeting_id' => $meeting_id,
            ':user_id'    => (int)$user_id
        ]);
    }
}

/* ===============================
   REDIRECT SUCCESS
   =============================== */
header("Location: ../pages/meeting_create.php?ok=1&id=" . $meeting_id);
exit;
