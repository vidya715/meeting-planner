<?php
require '../includes/config.php';
header("Content-Type: text/plain");

$data = json_decode(file_get_contents("php://input"), true);
if (!$data) {
    echo "Invalid data received";
    exit;
}

$meeting_id = intval($data['meeting_id'] ?? 0);
$attendance = $data['attendance'] ?? [];

if ($meeting_id <= 0 || empty($attendance)) {
    echo "Invalid meeting or attendance data";
    exit;
}

$stmt = $pdo->prepare("
    INSERT INTO attendance (meeting_id, user_id, present, arrival_time)
    VALUES (:meeting_id, :user_id, :present, :arrival_time)
    ON DUPLICATE KEY UPDATE
        present = VALUES(present),
        arrival_time = VALUES(arrival_time)
");

foreach ($attendance as $a) {
    $user_id = intval($a['user_id']);
    $present = ($a['status'] === "Present") ? 1 : 0;
    $arrival_time = $present ? ($a['arrival_time'] ?? null) : null;

    $stmt->execute([
        ':meeting_id' => $meeting_id,
        ':user_id' => $user_id,
        ':present' => $present,
        ':arrival_time' => $arrival_time
    ]);
}

echo "✅ Attendance saved successfully!";
?>
