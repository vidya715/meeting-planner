<?php
require __DIR__ . '/../includes/config.php';
session_start();
if($_SERVER['REQUEST_METHOD']!=='POST'){ header("Location: ../pages/assign_task.php"); exit; }

$title=trim($_POST['title']??''); $desc=trim($_POST['description']??'');
$mid=(int)($_POST['meeting_id']??0); $to=(int)($_POST['assigned_to']??0);
$priority=$_POST['priority']??'NORMAL'; $deadline=$_POST['deadline']??null;
$by = $_SESSION['user']['id']??null;

if($title && $mid && $to){
  if($by){
    $s=$conn->prepare("INSERT INTO tasks(title,description,assigned_to,assigned_by,meeting_id,deadline,status,priority,created_at)
                       VALUES(?,?,?,?,?,?, 'OPEN', ?, NOW())");
    $s->bind_param("ssiiiss",$title,$desc,$to,$by,$mid,$deadline,$priority);
  }else{
    $s=$conn->prepare("INSERT INTO tasks(title,description,assigned_to,meeting_id,deadline,status,priority,created_at)
                       VALUES(?,?,?,?,?, 'OPEN', ?, NOW())");
    $s->bind_param("ssiiss",$title,$desc,$to,$mid,$deadline,$priority);
  }
  $s->execute();
}
header("Location: ../pages/assign_task.php?ok=1");
