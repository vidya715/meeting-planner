<?php
header("Content-Type: application/json");
require_once "../includes/config.php";

$taskId = $_GET['task_id'] ?? 0;
if (!$taskId) {
    echo json_encode(["error" => "Missing task_id"]);
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT 
            t.id, 
            t.title, 
            t.description, 
            t.department, 
            t.deadline,
            t.status,
            u1.name AS assigned_to_name,
            u2.name AS assigned_by_name
        FROM tasks t
        LEFT JOIN users u1 ON t.assigned_to = u1.id
        LEFT JOIN users u2 ON t.assigned_by = u2.id
        WHERE t.id = ?
    ");
    $stmt->execute([$taskId]);
    $task = $stmt->fetch();

    echo json_encode($task ?: ["error" => "Task not found"]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>
