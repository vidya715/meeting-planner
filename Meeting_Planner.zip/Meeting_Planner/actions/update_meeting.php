<?php
require __DIR__ . '/../includes/config.php';
session_start();

// ✅ Ensure it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../pages/meeting_list.php");
    exit;
}

$meeting_id   = intval($_POST['id'] ?? 0);
$title        = trim($_POST['title'] ?? '');
$meeting_date = $_POST['meeting_date'] ?? '';
$meeting_time = $_POST['meeting_time'] ?? '';
$duration     = intval($_POST['duration'] ?? 0);
$mode         = $_POST['mode'] ?? 'ONLINE';
$location     = trim($_POST['location'] ?? '');
$department   = trim($_POST['department'] ?? '');
$agenda       = trim($_POST['agenda'] ?? '');
$attendees    = $_POST['attendees'] ?? [];
$file_path    = null;

// ✅ Handle file upload (if any)
if (!empty($_FILES['file']['name'])) {
    $allowed = ['pdf','jpg','jpeg','png','doc','docx','txt'];
    $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));

    if (in_array($ext, $allowed)) {
        $upload_dir = __DIR__ . '/../uploads/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

        $safe_name = time() . '_' . preg_replace("/[^a-zA-Z0-9_\.-]/", "_", $_FILES['file']['name']);
        $upload_path = $upload_dir . $safe_name;

        if (move_uploaded_file($_FILES['file']['tmp_name'], $upload_path)) {
            $file_path = 'uploads/' . $safe_name;
        }
    }
}

// ✅ Update meeting details using PDO
$query = "UPDATE meetings 
          SET title = :title,
              meeting_date = :meeting_date,
              meeting_time = :meeting_time,
              duration = :duration,
              mode = :mode,
              location = :location,
              department = :department,
              agenda = :agenda";

$params = [
    ':title'        => $title,
    ':meeting_date' => $meeting_date,
    ':meeting_time' => $meeting_time,
    ':duration'     => $duration,
    ':mode'         => $mode,
    ':location'     => $location,
    ':department'   => $department,
    ':agenda'       => $agenda,
];

if ($file_path) {
    $query .= ", file_path = :file_path";
    $params[':file_path'] = $file_path;
}

$query .= " WHERE id = :id";
$params[':id'] = $meeting_id;

$stmt = $pdo->prepare($query);
$stmt->execute($params);

// ✅ Update attendees list
$pdo->prepare("DELETE FROM meeting_attendees WHERE meeting_id = :mid")
    ->execute([':mid' => $meeting_id]);

if (!empty($attendees)) {
    $insert_stmt = $pdo->prepare("INSERT INTO meeting_attendees (meeting_id, user_id) VALUES (:mid, :uid)");
    foreach ($attendees as $uid) {
        $insert_stmt->execute([
            ':mid' => $meeting_id,
            ':uid' => intval($uid)
        ]);
    }
}

// ✅ Redirect with success message
header("Location: ../pages/meeting_list.php?updated=1");
exit;
?>
