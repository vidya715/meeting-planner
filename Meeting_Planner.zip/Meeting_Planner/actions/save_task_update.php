<?php
require __DIR__ . '/../includes/config.php';
session_start();
if($_SERVER['REQUEST_METHOD']!=='POST'){ header("Location: ../pages/review_tasks.php"); exit; }

$task_id=(int)($_POST['task_id']??0);
$status=$_POST['status']??'OPEN';
$comment=trim($_POST['comment']??'');
$uid=$_SESSION['user']['id']??null;

if($task_id){
  $u=$conn->prepare("UPDATE tasks SET status=? WHERE id=?");
  $u->bind_param("si",$status,$task_id); $u->execute();
  if($comment!=='' || $uid){
    if($uid){
      $i=$conn->prepare("INSERT INTO task_updates(task_id,user_id,status,comment,created_at) VALUES(?,?,?,?,NOW())");
      $i->bind_param("iiss",$task_id,$uid,$status,$comment);
    }else{
      $i=$conn->prepare("INSERT INTO task_updates(task_id,status,comment,created_at) VALUES(?,?,?,NOW())");
      $i->bind_param("iss",$task_id,$status,$comment);
    }
    $i->execute();
  }
}
header("Location: ../pages/review_tasks.php?ok=1");
