<?php
session_start();

/* ---------- AUTH ---------- */
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy();
    header("Location: index.php");
    exit;
}

if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

$user = $_SESSION['user'];
require_once __DIR__ . '/includes/config.php';

$uid  = $user['id'];
$role = strtolower($user['role']);

/* ---- TASK COUNT QUERY BASED ON ROLE ---- */
if ($role === 'employee') {
    $sql = "SELECT status, COUNT(*) total FROM tasks 
            WHERE assigned_to = :uid GROUP BY status";
} elseif ($role === 'organiser') {
    $sql = "SELECT status, COUNT(*) total FROM tasks 
            WHERE assigned_by = :uid GROUP BY status";
} else { // collector
    $sql = "SELECT status, COUNT(*) total FROM tasks GROUP BY status";
}

$stmt = $pdo->prepare($sql);
$role === 'collector' ? $stmt->execute() : $stmt->execute(['uid' => $uid]);

$counts = ['COMPLETED'=>0, 'IN_PROGRESS'=>0, 'PENDING'=>0];
$totalTasks = 0;

foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $counts[$row['status']] = (int)$row['total'];
    $totalTasks += (int)$row['total'];
}

/* ---- PERCENTAGES ---- */
$completedPct = $totalTasks ? floor(($counts['COMPLETED'] / $totalTasks) * 100) : 0;
$progressPct  = $totalTasks ? floor(($counts['IN_PROGRESS'] / $totalTasks) * 100) : 0;

// ensure total = 100
$pendingPct   = 100 - ($completedPct + $progressPct);

$circleOffset = 327 - (327 * $completedPct / 100);

/* ---------- DASHBOARD CARDS ---------- */
$allCards = [
    "organizer" => [
        [
            "label" => "Create Meeting",
            "description" => "Schedule and manage meetings effortlessly.",
            "image" => "https://cdn-icons-png.flaticon.com/512/945/945285.png",
            "gradient" => "linear-gradient(145deg,#4f4bdb 0%,#6c68ff 45%,#b6b4ff 100%)"
        ],

        [
            "label" => "Manage Meetings",
            "description" => "Track and mark attendance in real-time.",
            "image" => "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",
            "gradient" => "linear-gradient(145deg,#168f5b 0%,#28c76f 45%,#6be9b0 100%)"
        ],

        [
            "label" => "Mark Attendance",
            "description" => "Assign and manage employee tasks easily.",
            "image" => "https://cdn-icons-png.flaticon.com/512/1828/1828919.png",
            "gradient" => "linear-gradient(145deg,#007d92 0%,#00cfe8 45%,#1ed4ff 100%)"
        ],

        [
            "label" => "Meeting Notes",
            "description" => "Monitor task completion progress.",
            "image" => "https://cdn-icons-png.flaticon.com/512/3094/3094830.png",
            "gradient" => "linear-gradient(145deg,#d97918 0%,#ff9f43 45%,#ffd194 100%)"
        ],

        [
            "label" => "Assign Tasks",
            "description" => "Log and organize meeting minutes (MoM).",
            "image" => "https://cdn-icons-png.flaticon.com/512/2910/2910791.png",
            "gradient" => "linear-gradient(145deg,#b8326a 0%,#ea5455 45%,#f3a2a3 100%)"
        ],

        [
            "label" => "Review Tasks",
            "description" => "Track & review assigned work.",
            "image" => "https://cdn-icons-png.flaticon.com/512/535/535188.png",
            "gradient" => "linear-gradient(145deg,#0e9f98 0%,#20c997 45%,#7ff0df 100%)"
        ],
    ],
    "employee" => [
        [
            "label" => "My Meetings",
            "description" => "View meetings assigned to you.",
            "image" => "https://cdn-icons-png.flaticon.com/512/945/945285.png",
            "gradient" => "linear-gradient(145deg,#564fe3 0%,#7367f0 45%,#b3b1ff 100%)"
        ],

        [
            "label" => "My Tasks",
            "description" => "Complete your assigned tasks.",
            "image" => "https://cdn-icons-png.flaticon.com/512/1828/1828919.png",
            "gradient" => "linear-gradient(145deg,#0099b3 0%,#00cfe8 45%,#6ae6ff 100%)"
        ],
    ]
];

$role = strtolower($user['role']);
$role = strtolower($user['role']);

if ($role === 'collector') {
    // ✅ Collector sees ONLY meetings + task progress
    $workspaceCards = [
        [
            "label" => "All  Meetings",
            "description" => "View all meetings.",
            "image" => "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",
            "gradient" => "linear-gradient(145deg,#168f5b 0%,#28c76f 45%,#6be9b0 100%)"
        ],
        [
            "label" => "Task Progress",
            "description" => "View task progress across meetings.",
            "image" => "https://cdn-icons-png.flaticon.com/512/535/535188.png",
            "gradient" => "linear-gradient(145deg,#0e9f98 0%,#20c997 45%,#7ff0df 100%)"
        ],
    ];
} else {
    $workspaceCards = $allCards[$role] ?? $allCards['organizer'];
}

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Dashboard | Meeting Planner</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/sidebar.css">


    <style>
        body {
            background: #f2f5fb;
            font-family: "Segoe UI", sans-serif;
            margin: 0;
        }


        /* ---------- DARK LAVENDER HEADER ---------- */
        .header {
            background: linear-gradient(135deg,
                    #beb2edff 0%,
                    rgba(177, 161, 236, 1) 45%,
                    rgba(186, 178, 242, 1) 100%);
            border-radius: 18px;
            padding: 1.6rem 2rem;
            margin-bottom: 2.2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow:
                0 20px 45px rgba(58, 45, 111, .45),
                inset 0 1px 0 rgba(255, 255, 255, .15);
        }

        .header h4 {
            font-weight: 700;
            color: #ffffff;
        }

        .header p {
            color: #dcd6ff;
        }

        /* logout */
        .logout-btn {
            background: linear-gradient(135deg, #ff5f6d, #ff2e2e);
            color: #fff;
            padding: .5rem 1rem;
            border-radius: .6rem;
            text-decoration: none;
            font-size: .9rem;
            box-shadow: 0 8px 18px rgba(255, 95, 109, .45);
        }

        /* ---------- CARDS ---------- */
        .workspace-card {
            position: relative;
            border-radius: 20px;
            padding: 1.7rem 1.4rem;
            color: #fff;
            min-height: 180px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            overflow: hidden;
            transition: all .35s ease;
            box-shadow:
                0 18px 40px rgba(0, 0, 0, .22),
                inset 0 1px 0 rgba(255, 255, 255, .35);
        }

        .workspace-card::before {
            content: "";
            position: absolute;
            inset: 0;
            background: linear-gradient(120deg,
                    rgba(255, 255, 255, .35),
                    rgba(255, 255, 255, .08) 45%,
                    rgba(0, 0, 0, .12));
            pointer-events: none;
        }

        .workspace-card:hover {
            transform: translateY(-8px) scale(1.015);
            box-shadow: 0 26px 55px rgba(0, 0, 0, .3);
        }

        .icon-wrap {
            width: 62px;
            height: 62px;
            background: rgba(255, 255, 255, .25);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
            box-shadow:
                inset 0 1px 2px rgba(255, 255, 255, .6),
                0 6px 14px rgba(0, 0, 0, .25);
        }

        .icon-wrap img {
            width: 36px;
            height: 36px;
        }

        .workspace-card h6 {
            font-size: 1.05rem;
            font-weight: 700;
            margin-bottom: .35rem;
        }

        .workspace-card p {
            font-size: .88rem;
            opacity: .95;
        }

        @media(max-width:768px) {
            .header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
        }

        .app-layout {
            display: flex;
        }

        .main-content {
            margin-left: 250px;
            width: calc(100% - 250px);
            padding: 2rem;
            min-height: 100vh;
            transition: all 0.3s ease;
        }

        /* ===== PROGRESS OVERVIEW ===== */
.progress-card {
    background: rgba(255,255,255,0.85);
    backdrop-filter: blur(14px);
    border-radius: 18px;
    padding: 24px;
    box-shadow: 0 15px 40px rgba(0,0,0,.12);
    animation: fadeUp .8s ease forwards;
}

.progress-item {
    display: flex;
    justify-content: space-between;
    font-weight: 600;
    font-size: .9rem;
    margin-bottom: 6px;
}

.progress {
    height: 10px;
    border-radius: 10px;
    background: #e5e7eb;
    overflow: hidden;
}

.progress-bar {
    height: 100%;
    border-radius: 10px;
    animation: growBar 1.6s ease forwards;
}

.completed-bar {
    
    background: linear-gradient(90deg,#22c55e,#4ade80);
}

.inprogress-bar {
    
    background: linear-gradient(90deg,#38bdf8,#0ea5e9);
}

.pending-bar {

    background: linear-gradient(90deg,#f97316,#fb923c);
}

/* ===== CIRCLE PROGRESS ===== */
.circle-wrap {
    position: relative;
    width: 120px;
    margin: auto;
}

.circle-wrap svg circle {
    fill: none;
    stroke-width: 10;
    
}
.circle-wrap svg {
    transform: rotate(-90deg);
}

.circle-progress {
    stroke: #22c55e;
    stroke-dasharray: 327;
    stroke-dashoffset: 92;
    stroke-linecap: round;
    animation: circleAnim 1.8s ease forwards;
}

.circle-text {
    position: absolute;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 1.4rem;
    color: #16a34a;
}

/* ===== ANIMATIONS ===== */
@keyframes growBar {
    from { width: 0; }
}

@keyframes circleAnim {
    from { stroke-dashoffset: 327; }
}



    </style>
</head>

<body>

    <div class="app-layout">

        <?php include 'includes/sidebar.php'; ?>

        <div class="main-content">

            <!-- HEADER -->
            <div class="header">
                <div class="d-flex align-items-center">
                    <button class="hamburger" onclick="toggleSidebar()">
                        <i class="fas fa-bars"></i>
                    </button>

                    <div>
                        <h4 class="mb-1">
                            Welcome, <?= htmlspecialchars(explode(" ", $user['name'])[0]) ?> 👋
                        </h4>
                        <p class="mb-0">
                            Role: <strong><?= htmlspecialchars($user['role']) ?></strong>
                        </p>
                    </div>
                </div>

                <a href="?action=logout" class="logout-btn">Logout</a>
            </div>
<!-- ===== TASK PROGRESS OVERVIEW ===== -->
<div class="container-fluid mb-4">
    <div class="row g-4">

        <div class="col-12 col-lg-8">
            <div class="progress-card">
                <h5 class="mb-3 fw-bold">📊 Task Progress Overview</h5>

                <div class="progress-item">
                    <span>Completed Tasks</span>
                   <span class="percent completed"><?= $completedPct ?>%</span>
                </div>
                <div class="progress">
                   <div class="progress-bar completed-bar" style="width: <?= $completedPct ?>%"></div>

                </div>

                <div class="progress-item mt-3">
                    <span>In Progress</span>
                   <span class="percent progress-text"><?= $progressPct ?>%</span>
                </div>
                <div class="progress">
    <div class="progress-bar inprogress-bar"
         style="width: <?= $progressPct ?>%"></div>
</div>


                <div class="progress-item mt-3">
                    <span>Pending Tasks</span>
                   <span class="percent pending"><?= $pendingPct ?>%</span>
                </div>
                <div class="progress">
                   <div class="progress-bar pending-bar" style="width: <?= $pendingPct ?>%"></div>

                </div>

            </div>
        </div>

        <div class="col-12 col-lg-4">
            <div class="progress-card text-center">
                <h5 class="fw-bold mb-2">📌 Overall Completion</h5>
                <div class="circle-wrap">
                  <?php
$circumference = 2 * pi() * 52;

$completedLen = ($completedPct / 100) * $circumference;
$progressLen  = ($progressPct / 100) * $circumference;
$pendingLen   = ($pendingPct / 100) * $circumference;

$progressOffset = $completedLen;
$pendingOffset  = $completedLen + $progressLen;
?>

<svg width="120" height="120" viewBox="0 0 120 120">

    <!-- Base circle -->
    <circle cx="60" cy="60" r="52"
        stroke="#e5e7eb"
        stroke-width="10"
        fill="none" />

    <!-- Completed -->
    <?php if ($completedPct > 0): ?>
    <circle cx="60" cy="60" r="52"
        stroke="#22c55e"
        stroke-width="10"
        fill="none"
        stroke-dasharray="<?= $completedLen ?> <?= $circumference ?>"
        stroke-dashoffset="0"
        stroke-linecap="round" />
    <?php endif; ?>

    <!-- In Progress -->
    <?php if ($progressPct > 0): ?>
    <circle cx="60" cy="60" r="52"
        stroke="#0ea5e9"
        stroke-width="10"
        fill="none"
        stroke-dasharray="<?= $progressLen ?> <?= $circumference ?>"
        stroke-dashoffset="-<?= $progressOffset ?>"
        stroke-linecap="round" />
    <?php endif; ?>

    <!-- Pending -->
    <?php if ($pendingPct > 0): ?>
    <circle cx="60" cy="60" r="52"
        stroke="#f97316"
        stroke-width="10"
        fill="none"
        stroke-dasharray="<?= $pendingLen ?> <?= $circumference ?>"
        stroke-dashoffset="-<?= $pendingOffset ?>"
        stroke-linecap="round" />
    <?php endif; ?>

</svg>


                    <div class="circle-text"><?= $completedPct ?>%</div>
                </div>
                <p class="text-muted mt-3 small">Across all meetings</p>
            </div>
        </div>

    </div>
</div>


            <!-- DASHBOARD -->
            <div class="container-fluid">
                <div class="row g-4">
                    <?php foreach ($workspaceCards as $card): ?>
    <?php
    // Define destination links based on card label
    $links = [
        "Create Meeting"   => "pages/meeting_create.php",
        "Manage Meetings"  => "pages/meeting_list.php",
        "Mark Attendance"  => "pages/Attendance_form.php",
        "Meeting Notes"    => "pages/mom_notes.php",
        "Assign Tasks"     => "pages/assign-task.php",
        "Review Tasks"     => "pages/task_report.php",
        "My Meetings"      => "pages/meeting_list.php",
        "All  Meetings" => "pages/meeting_list.php",
"Task Progress" => "pages/task_report.php",
        "My Tasks"         => "pages/task_report.php",
    ];

    $target = $links[$card['label']] ?? "#"; // default to "#" if not mapped
    ?>
    <div class="col-12 col-sm-6 col-lg-4">
        <a href="<?= $target ?>" style="text-decoration: none;">
            <div class="workspace-card" style="background: <?= $card['gradient'] ?>;">
                <div class="icon-wrap">
                    <img src="<?= htmlspecialchars($card['image']) ?>" alt="">
                </div>
                <h6><?= htmlspecialchars($card['label']) ?></h6>
                <p><?= htmlspecialchars($card['description']) ?></p>
            </div>
        </a>
    </div>
<?php endforeach; ?>

                </div>
            </div>

        </div> <!-- main-content -->

    </div> <!-- app-layout -->


    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            const main = document.querySelector('.main-content');

            sidebar.classList.toggle('open');
            sidebar.classList.toggle('closed');
            main.classList.toggle('full');
        }

        /* Close sidebar on page load for mobile */
        if (window.innerWidth <= 992) {
            document.querySelector('.sidebar').classList.add('closed');
        }
    </script>

</body>

</html>