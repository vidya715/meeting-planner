<?php

return [
    "ORGANISER" => [
        [
            "label" => "Dashboard",
            "href" => "dashboard.php",
            "image" => "https://cdn-icons-png.flaticon.com/512/3024/3024593.png",
            "description" => ""
        ],
        [
            "label" => "Meetings",
            "href" => "meetings.php",
            "image" => "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",
            "description" => "Schedule and manage meetings effortlessly."
        ],
        [
            "label" => "Attendance",
            "href" => "attendance.php",
            "image" => "https://cdn-icons-png.flaticon.com/512/1828/1828919.png",
            "description" => "Track and mark attendance in real time."
        ],
        [
            "label" => "Tasks",
            "href" => "tasks.php",
            "image" => "https://cdn-icons-png.flaticon.com/512/2910/2910791.png",
            "description" => "Assign and monitor employee tasks."
        ],
        [
            "label" => "MoM",
            "href" => "mom.php",
            "image" => "https://cdn-icons-png.flaticon.com/512/3500/3500833.png",
            "description" => "Create and review Minutes of Meetings."
        ],
    ],

    "EMPLOYEE" => [
        [
            "label" => "Dashboard",
            "href" => "dashboard.php",
            "image" => "https://cdn-icons-png.flaticon.com/512/3135/3135789.png",
            "description" => ""
        ],
        [
            "label" => "My Meetings",
            "href" => "meetings.php",
            "image" => "https://cdn-icons-png.flaticon.com/512/4727/4727479.png",
            "description" => "View your upcoming and past meetings."
        ],
        [
            "label" => "My Tasks",
            "href" => "tasks.php",
            "image" => "https://cdn-icons-png.flaticon.com/512/906/906175.png",
            "description" => "Update and track assigned tasks."
        ],
    ],

    "COLLECTOR" => [
        [
            "label" => "Dashboard",
            "href" => "dashboard.php",
            "image" => "https://cdn-icons-png.flaticon.com/512/3094/3094830.png",
            "description" => ""
        ],
        [
            "label" => "Meetings",
            "href" => "meetings.php",
            "image" => "https://cdn-icons-png.flaticon.com/512/535/535188.png",
            "description" => "Review all meetings and discussions."
        ],
        [
            "label" => "Task Summary",
            "href" => "tasks.php",
            "image" => "https://cdn-icons-png.flaticon.com/512/3550/3550370.png",
            "description" => "Analyze meeting-wise task summaries."
        ],
    ],
];