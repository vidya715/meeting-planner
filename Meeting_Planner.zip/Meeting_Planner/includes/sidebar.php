<?php
if (!isset($_SESSION['user'])) return;
$role = strtoupper($_SESSION['user']['role']);
?>

<!-- FONT AWESOME (REQUIRED FOR ICONS) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>
/* ================= SIDEBAR ================= */
.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 260px;
    height: 100vh;
    background: linear-gradient(180deg, #060D2A, #020617);
    color: #fff;
    padding-top: 1rem;
    box-shadow: 6px 0 30px rgba(0,0,0,0.45);
    transform: translateX(-100%);
    transition: transform 0.35s ease;
    z-index: 1200;
}
.sidebar.open { transform: translateX(0); }

.sidebar-header {
    text-align: center;
    padding: 1.6rem 1rem;
    border-bottom: 1px solid rgba(255,255,255,0.15);
}
.sidebar-header h5 {
    margin: 0;
    font-weight: 700;
    font-size: 1.3rem;
}
.sidebar-header small {
    font-size: 0.75rem;
    letter-spacing: 1px;
    opacity: 0.85;
}

.sidebar-menu {
    list-style: none;
    padding: 0;
    margin: 1rem 0;
}
.sidebar-menu li { margin: 0.35rem 0; }

.sidebar-menu a {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 0.8rem 1.6rem;
    color: #e5e7eb;
    text-decoration: none;
    font-size: 0.95rem;
    border-radius: 10px;
    margin: 0 10px;
    transition: all 0.25s ease;
}

.sidebar-menu i {
    width: 20px;
    text-align: center;
    font-size: 1rem;
    color: #c7d2fe;
}

.sidebar-menu a:hover,
.sidebar-menu a.active {
    background: #7c7cf8;
    color: #ffffff;
    box-shadow: 0 6px 16px rgba(124,124,248,0.45);
}
.sidebar-menu a:hover i,
.sidebar-menu a.active i {
    color: #ffffff;
}

.sidebar-menu .logout a {
    margin-top: 1.2rem;
    background: rgba(239,68,68,0.08);
}
.sidebar-menu .logout a:hover {
    background: rgba(239,68,68,0.25);
    box-shadow: 0 6px 16px rgba(239,68,68,0.45);
}
</style>

<div class="sidebar open" id="sidebar">

    <div class="sidebar-header">
        <h5>Meeting Planner</h5>
        <small><?= htmlspecialchars($role) ?></small>
    </div>

    <ul class="sidebar-menu">

        <!-- COMMON -->
        <li>
            <a href="/Meeting_Planner/dashboard.php">
                <i class="fas fa-home"></i> Dashboard
            </a>
        </li>

        <!-- ORGANISER -->
        <?php if ($role === 'ORGANISER'): ?>
            <li><a href="/Meeting_Planner/pages/meeting_create.php"><i class="fas fa-calendar-plus"></i> Create Meeting</a></li>
            <li><a href="/Meeting_Planner/pages/meeting_list.php"><i class="fas fa-calendar-check"></i> Manage Meetings</a></li>
            <li><a href="/Meeting_Planner/pages/Attendance_form.php"><i class="fas fa-user-check"></i> Mark Attendance</a></li>
            <li><a href="/Meeting_Planner/pages/mom_notes.php"><i class="fas fa-sticky-note"></i> Meeting Notes</a></li>
            <li><a href="/Meeting_Planner/pages/assign-task.php"><i class="fas fa-tasks"></i> Assign Tasks</a></li>
            <li><a href="/Meeting_Planner/pages/task_report.php"><i class="fas fa-clipboard-list"></i> Review Tasks</a></li>
        <?php endif; ?>

        <!-- COLLECTOR -->
        <?php if ($role === 'COLLECTOR'): ?>
            <li><a href="/Meeting_Planner/pages/meeting_list.php"><i class="fas fa-calendar-check"></i> Manage Meetings</a></li>
            <li><a href="/Meeting_Planner/pages/task_report.php"><i class="fas fa-clipboard-list"></i> Review Tasks</a></li>
            
        <?php endif; ?>

        <!-- EMPLOYEE -->
        <?php if ($role === 'EMPLOYEE'): ?>
            <li><a href="/Meeting_Planner/pages/meeting_list.php"><i class="fas fa-calendar"></i> My Meetings</a></li>
            <li><a href="/Meeting_Planner/pages/task_report.php"><i class="fas fa-tasks"></i> My Tasks</a></li>
           
        <?php endif; ?>

        <!-- LOGOUT -->
        <li class="logout">
            <a href="/Meeting_Planner/dashboard.php?action=logout">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </li>

    </ul>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const hamburger = document.getElementById("hamburger");
    const sidebar = document.getElementById("sidebar");

    if (hamburger && sidebar) {
        hamburger.addEventListener("click", function () {
            sidebar.classList.toggle("open");
        });
    }
});
</script>
