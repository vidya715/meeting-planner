<?php
// ===============================
// Database Configuration (PDO)
// ===============================

// Set PHP timezone to India Standard Time
date_default_timezone_set("Asia/Kolkata");

// Database credentials
$DB_HOST = "103.160.107.18";
$DB_USER = "nmrmlatur_internshipUser";
$DB_PASS = "Intern#User2025";
$DB_NAME = "nmrmlatur_spic_7_thecompilers";
$DB_PORT = 3306;

// DSN (Data Source Name)
$dsn = "mysql:host={$DB_HOST};port={$DB_PORT};dbname={$DB_NAME};charset=utf8mb4";

// PDO options for reliability and performance
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Throw exceptions on errors
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Return results as associative arrays
    PDO::ATTR_EMULATE_PREPARES   => false,                  // Use native prepared statements
];

try {
    // ✅ Create PDO connection
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS, $options);

    // ✅ Sync MySQL timezone with IST (important for correct timestamps)
    $pdo->exec("SET time_zone = '+05:30'");

} catch (PDOException $e) {
    // Stop execution if connection fails
    http_response_code(500);
    die("❌ Database connection failed: " . htmlspecialchars($e->getMessage()));
}

// ===============================
// Function: Get a new PDO connection (if needed)
// ===============================
function getPDOConnection() {
    global $dsn, $DB_USER, $DB_PASS, $options;
    try {
        $pdo = new PDO($dsn, $DB_USER, $DB_PASS, $options);
        $pdo->exec("SET time_zone = '+05:30'");
        return $pdo;
    } catch (PDOException $e) {
        error_log("PDO Reconnection failed: " . $e->getMessage());
        return null;
    }
}
?>
