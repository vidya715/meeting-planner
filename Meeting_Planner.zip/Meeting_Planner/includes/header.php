<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$active = $active ?? '';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($page_title ?? 'Meeting Planner') ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{
  --ink:#0f172a; --muted:#64748b; --bg:#f6f7fb;
  --slate:#111827; --card:#ffffff; --border:#e5e7eb;
  --gold:#c0841a; --gold-2:#f59e0b; --gold-soft:#fff7ed;
}
*{font-family:Inter,system-ui,Segoe UI,Arial,sans-serif}
body{background:var(--bg); color:var(--slate)}
.navbar{background:linear-gradient(135deg,#111827 0%,#1f2937 100%); box-shadow:0 6px 18px rgba(0,0,0,.1)}
.navbar .nav-link{color:#e5e7eb; font-weight:600; border-radius:10px; padding:.55rem .85rem}
.navbar .nav-link.active,.navbar .nav-link:hover{background:rgba(192,132,26,.16); color:#f8fafc}
.badge-gold{background:rgba(192,132,26,.12); color:#c0841a; border:1px solid rgba(192,132,26,.22)}
.btn-gold{background:linear-gradient(135deg,#c0841a,#f59e0b); border:none; color:#111827}
.btn-gold:hover{filter:brightness(.98); box-shadow:0 8px 24px rgba(245,158,11,.28)}
.card-soft{background:var(--card); border:1px solid var(--border); border-radius:16px; box-shadow:0 8px 28px rgba(2,8,23,.06)}
.link-muted{color:var(--muted); text-decoration:none}
.link-muted:hover{color:#0ea5e9}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark mb-4">
  <div class="container">
    <a class="navbar-brand fw-bold" href="/Meeting_Planner/pages/meeting_list.php">
      <i class="bi bi-journal-check me-2 text-warning"></i>Meeting Planner
    </a>
    <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#topnav"><span class="navbar-toggler-icon"></span></button>
    <div id="topnav" class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto gap-1">
        <li class="nav-item"><a class="nav-link <?= $active==='create'?'active':''?>" href="/Meeting_Planner/pages/meeting_create.php">Create Meeting</a></li>
        <li class="nav-item"><a class="nav-link <?= $active==='list'?'active':''?>" href="/Meeting_Planner/pages/meeting_list.php">Manage Meetings</a></li>
        <li class="nav-item"><a class="nav-link <?= $active==='attendance'?'active':''?>" href="/Meeting_Planner/pages/attendance_mark.php">Mark Attendance</a></li>
        <li class="nav-item"><a class="nav-link <?= $active==='notes'?'active':''?>" href="/Meeting_Planner/pages/meeting_notes.php">Meeting Notes</a></li>
        <li class="nav-item"><a class="nav-link <?= $active==='assign'?'active':''?>" href="/Meeting_Planner/pages/assign_task.php">Assign Tasks</a></li>
        <li class="nav-item"><a class="nav-link <?= $active==='review'?'active':''?>" href="/Meeting_Planner/pages/review_tasks.php">Review Tasks</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="container mb-4">
