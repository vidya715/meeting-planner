<?php
// mock-auth.php
session_start();

/**
 * DEV ONLY — remove or protect in production
 */
// if (($_SERVER['APP_ENV'] ?? '') !== 'local') {
//     http_response_code(403);
//     exit('Mock auth disabled');
// }

/**
 * Mock users
 */
$mockUsers = [
    1 => [
        "id" => 1,
        "name" => "Alice Collector",
        "email" => "alice.collector@example.com",
        "role" => "COLLECTOR",
    ],
    2 => [
        "id" => 2,
        "name" => "Bob Organizer",
        "email" => "bob.organizer@example.com",
        "role" => "ORGANISER",
    ],
    3 => [
        "id" => 3,
        "name" => "Charlie Employee",
        "email" => "charlie.employee@example.com",
        "role" => "EMPLOYEE",
    ],
    4 => [
        "id" => 4,
        "name" => "Diana Employee",
        "email" => "diana.employee@example.com",
        "role" => "EMPLOYEE",
    ],
    5 => [
        "id" => 5,
        "name" => "Evan Organizer",
        "email" => "evan.organizer@example.com",
        "role" => "ORGANISER",
    ],
];

/**
 * Get user by ID from URL
 */
$id = isset($_GET['id']) ? (int) $_GET['id'] : null;

if (!$id || !isset($mockUsers[$id])) {
    http_response_code(400);
    echo "Invalid mock user ID. Use ?id=1..5";
    exit;
}

/**
 * Log in mock user
 */
$_SESSION['user'] = $mockUsers[$id];

/**
 * Redirect to dashboard
 */
header("Location: dashboard.php");
exit;