$(document).ready(function () {

    // Enable / disable arrival time
    $(".status-toggle").change(function () {

        let timeInput = $(this).closest("tr").find(".arrival-time");

        if ($(this).is(":checked")) {
            timeInput.prop("disabled", false);
            let now = new Date().toTimeString().slice(0, 5);
            timeInput.val(now);
        } else {
            timeInput.prop("disabled", true);
            timeInput.val("");
        }
    });

    // Save attendance via AJAX
    $("#saveAttendance").click(function () {

        let meeting_id = $("#meeting_id").val();

        if (meeting_id === "") {
            alert("Please select meeting");
            return;
        }

        let attendance = [];

        // Collect data from table rows
        $("tbody tr").each(function () {
            attendance.push({
                attendee_name: $(this).find("td:first").text().trim(), // Use attendee_name
                status: $(this).find(".status-toggle").is(":checked") ? "Present" : "Absent",
                arrival_time: $(this).find(".arrival-time").val()
            });
        });

        // Send via AJAX to PHP
        $.post(
            "save_attendance.php",
            { meeting_id: meeting_id, attendance: attendance },
            function (res) {
                $("#msg").html('<div class="alert alert-success">' + res + '</div>');
            }
        );
    });

});