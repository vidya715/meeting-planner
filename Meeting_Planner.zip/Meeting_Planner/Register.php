<?php
require __DIR__ . "/includes/config.php";

$message = "";

// Handle form submit
if (isset($_POST['register'])) {

    $first_name  = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name']);
    $last_name   = trim($_POST['last_name']);
    $username    = trim($_POST['username']);
    $email       = trim($_POST['email']);
    $password    = trim($_POST['password']);
    $mobile      = trim($_POST['mobile']);
    $department  = $_POST['department'];
    $role        = $_POST['role'];

    $full_name = trim(
        $first_name . " " .
        ($middle_name ? $middle_name . " " : "") .
        $last_name
    );

    if ($first_name === "" || $last_name === "") {
        $message = "First name and last name are required";
    } elseif ($username === "" || strlen($username) < 3) {
        $message = "Username must be at least 3 characters long";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Invalid email format";
    } elseif (strlen($password) < 6) {
        $message = "Password must be at least 6 characters long";
    } elseif (!preg_match('/^[5-9][0-9]{9}$/', $mobile)) {
        $message = "Mobile number must start with 5-9 and be exactly 10 digits";
    } else {

        /* ✅ CHECK IF EMAIL EXISTS (PDO) */
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);

        if ($stmt->rowCount() > 0) {
            $message = "Email already registered";
        } else {

            /* ✅ INSERT USER (PDO) */
            $insert = $pdo->prepare("
                INSERT INTO users
                (name, email, password, role, department,
                 first_name, middle_name, last_name, full_name, mobile)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $success = $insert->execute([
                $username,
                $email,
                $password,   // (password_hash optional later)
                $role,
                $department,
                $first_name,
                $middle_name,
                $last_name,
                $full_name,
                $mobile
            ]);

            if ($success) {
                header("Location: index.php?success=1");
                exit;
            } else {
                $message = "Registration failed. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Create Account | Meeting & Task Planner</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f5f7fb;
            font-family: "Inter", system-ui, sans-serif;
        }

        .page-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .register-card {
            width: 100%;
            max-width: 900px;
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 30px 80px rgba(0,0,0,0.15);
            display: grid;
            grid-template-columns: 280px 1fr;
            overflow: hidden;
        }

        .register-sidebar {
            background: linear-gradient(180deg, #0f172a, #1e293b);
            color: #fff;
            padding: 40px 25px;
        }

        .register-sidebar h4 {
            font-weight: 600;
            margin-bottom: 30px;
        }

        .step {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 18px;
            font-size: 14px;
            opacity: 0.85;
        }

        .step span {
            width: 26px;
            height: 26px;
            border-radius: 50%;
            background: #8478FC;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 13px;
            font-weight: 600;
        }

        .register-form {
            padding: 45px 50px;
        }

        .register-title {
            font-size: 26px;
            font-weight: 600;
            margin-bottom: 6px;
        }

        .register-subtitle {
            color: #6b7280;
            margin-bottom: 30px;
            font-size: 14px;
        }

        .form-label {
            font-size: 13px;
            font-weight: 500;
            color: #374151;
        }

        .form-control,
        .form-select {
            padding: 11px 14px;
            border-radius: 10px;
            border: 1px solid #d1d5db;
            font-size: 14px;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #8478FC;
            box-shadow: 0 0 0 3px rgba(132,120,252,0.2);
        }

        .btn-register {
            background: #8478FC;
            border: none;
            padding: 13px;
            border-radius: 12px;
            color: #fff;
            font-weight: 500;
            font-size: 15px;
            transition: 0.25s;
        }

        .btn-register:hover {
            background: #6f63e6;
        }

        .form-footer {
            margin-top: 18px;
            font-size: 14px;
            text-align: center;
        }

        .form-footer a {
            color: #8478FC;
            font-weight: 500;
            text-decoration: none;
        }

        @media (max-width: 992px) {
            .register-card {
                grid-template-columns: 1fr;
            }
            .register-sidebar {
                display: none;
            }
        }
    </style>
</head>

<body>

<div class="page-wrapper">
    <div class="register-card">

        <div class="register-sidebar">
            <h4>Registration Steps</h4>
            <div class="step"><span>1</span> Personal Details</div>
            <div class="step"><span>2</span> Account Setup</div>
            <div class="step"><span>3</span> Role & Department</div>
        </div>

        <div class="register-form">
            <h2 class="register-title">Create Account</h2>
            <p class="register-subtitle">Fill in the details to access Meeting & Task Planner</p>

            <?php if ($message): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="row g-3">

                    <div class="col-md-4">
                        <label class="form-label">First Name</label>
                        <input class="form-control" name="first_name" required>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Middle Name</label>
                        <input class="form-control" name="middle_name">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Last Name</label>
                        <input class="form-control" name="last_name" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Username</label>
                        <input class="form-control" name="username" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" name="email" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Mobile</label>
                        <input type="text" name="mobile" class="form-control"
                               required maxlength="10"
                               pattern="[6-9][0-9]{9}">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Department</label>
                        <select class="form-select" name="department" required>
                            <option value="">Select</option>
                            <option>Management</option>
                            <option>IT</option>
                            <option>HR</option>
                            <option>Finance</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Role</label>
                        <select class="form-select" name="role" required>
                            <option value="">Select</option>
                            <option value="ORGANISER">Organiser</option>
                            <option value="EMPLOYEE">Employee</option>
                            <option value="COLLECTOR">Collector</option>
                        </select>
                    </div>
                </div>

                <button class="btn btn-register w-100 mt-4" name="register">
                    Create Account
                </button>

                <div class="form-footer">
                    Already have an account? <a href="index.php">Sign in</a>
                </div>

            </form>
        </div>
    </div>
</div>

</body>
</html>
