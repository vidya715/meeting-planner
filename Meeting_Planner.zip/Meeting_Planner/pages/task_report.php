<?php
session_start();
require '../includes/config.php';

/* ---------- AUTH CHECK ---------- */
if (!isset($_SESSION['user'])) {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user']['id'];
$role    = strtoupper($_SESSION['user']['role']); // EMPLOYEE / ORGANISER / COLLECTOR

/* ---------- FETCH TASKS BASED ON ROLE (SRS) ---------- */
try {

    if ($role === 'EMPLOYEE') {
        $sql = "
            SELECT t.*,
                   n.title AS note_title,
                   u1.name AS assigned_to_name,
                   u2.name AS assigned_by_name
            FROM tasks t
            LEFT JOIN notes n ON t.note_id = n.id
            LEFT JOIN users u1 ON t.assigned_to = u1.id
            LEFT JOIN users u2 ON t.assigned_by = u2.id
            WHERE t.assigned_to = :uid
            ORDER BY n.title, t.id DESC
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['uid' => $user_id]);

    } elseif ($role === 'ORGANISER') {
        $sql = "
            SELECT t.*,
                   n.title AS note_title,
                   u1.name AS assigned_to_name,
                   u2.name AS assigned_by_name
            FROM tasks t
            LEFT JOIN notes n ON t.note_id = n.id
            LEFT JOIN users u1 ON t.assigned_to = u1.id
            LEFT JOIN users u2 ON t.assigned_by = u2.id
            WHERE t.assigned_by = :uid
            ORDER BY n.title, t.id DESC
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['uid' => $user_id]);

    } else {
        $sql = "
            SELECT t.*,
                   n.title AS note_title,
                   u1.name AS assigned_to_name,
                   u2.name AS assigned_by_name
            FROM tasks t
            LEFT JOIN notes n ON t.note_id = n.id
            LEFT JOIN users u1 ON t.assigned_to = u1.id
            LEFT JOIN users u2 ON t.assigned_by = u2.id
            ORDER BY n.title, t.id DESC
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
    }

    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database Error: " . htmlspecialchars($e->getMessage()));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Task Report</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    font-family: "Poppins", sans-serif;
    background: linear-gradient(135deg, #f3e8ff, #f8f5ff);
    min-height: 100vh;
    padding: 30px;
}

/* ✅ ONLY ADDITION */
.page-wrapper {
    margin-left: 260px; /* same sidebar width */
}

.main-card {
    max-width: 1200px;
    margin: auto;
    background: #fff;
    border-radius: 18px;
    box-shadow: 0 10px 25px rgba(123,110,246,0.2);
    padding: 30px;
}

.header {
    background: linear-gradient(90deg, #7b6ef6, #a58bff);
    color: white;
    padding: 25px;
    text-align: center;
    border-radius: 14px;
    margin-bottom: 30px;
}

.task-section {
    background: #fff;
    border-radius: 16px;
    padding: 25px;
    margin-bottom: 25px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.08);
}

.task-card {
    background: #fff;
    border-left: 6px solid #7b6ef6;
    padding: 18px;
    border-radius: 14px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    margin-bottom: 20px;
}
</style>
</head>

<body>

<!-- ✅ SIDEBAR (ONLY ADDED) -->
<?php include __DIR__ . '/../includes/sidebar.php'; ?>

<!-- ✅ WRAPPER (ONLY ADDED) -->
<div class="page-wrapper">

<div class="main-card">
    <div class="header">
        <h2>📋 Task Report</h2>
        <p class="mb-0">Overview of assigned tasks</p>
    </div>

    <?php if (empty($tasks)): ?>
        <div class="text-center text-muted py-5">No tasks found.</div>
    <?php else: ?>

        <?php
        $grouped = [];
        foreach ($tasks as $t) {
            $grouped[$t['note_title'] ?? 'Untitled Meeting'][] = $t;
        }
        ?>

        <?php foreach ($grouped as $meetingTitle => $meetingTasks): ?>
            <div class="task-section">
                <h5 class="fw-bold text-primary mb-3">
                    Meeting: <?= htmlspecialchars($meetingTitle) ?>
                </h5>

                <div class="row">
                    <?php foreach ($meetingTasks as $task): ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="task-card">
                                <h6 class="fw-bold text-primary mb-2">
                                    <?= htmlspecialchars($task['title']) ?>
                                </h6>

                                <ul class="list-unstyled small mb-3 text-muted">
                                    <li><strong>Status:</strong> <?= htmlspecialchars($task['status']) ?></li>
                                    <li><strong>Deadline:</strong>
                                        <?= date('d M Y, h:i A', strtotime($task['deadline'])) ?>
                                    </li>
                                    <li><strong>Assigned To:</strong> <?= htmlspecialchars($task['assigned_to_name']) ?></li>
                                    <li><strong>Assigned By:</strong> <?= htmlspecialchars($task['assigned_by_name']) ?></li>
                                    <li><strong>Department:</strong> <?= htmlspecialchars($task['department']) ?></li>
                                </ul>

                                <?php if ($role === 'EMPLOYEE'): ?>
                                    <a href="../pages/task_update.php?id=<?= $task['id'] ?>" class="btn btn-primary w-100">
                                        Update Task Status
                                    </a>
                                <?php elseif ($role === 'ORGANISER'): ?>
                                    <p class="text-center text-muted small mb-0">
                                        👁 View only (Organiser Review)
                                    </p>
                                <?php else: ?>
                                    <p class="text-center text-muted small mb-0">
                                        🔒 Read-only access (Collector)
                                    </p>
                                <?php endif; ?>

                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>

    <?php endif; ?>
</div>

</div>

</body>
</html>
