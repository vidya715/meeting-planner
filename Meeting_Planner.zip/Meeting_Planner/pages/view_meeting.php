<?php
require __DIR__ . '/../includes/config.php';
session_start();

$meeting_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// ✅ Fetch meeting details using PDO
$stmt = $pdo->prepare("SELECT * FROM meetings WHERE id = :id");
$stmt->execute([':id' => $meeting_id]);
$meeting = $stmt->fetch(PDO::FETCH_ASSOC);

// ✅ Fetch attendees using PDO
$att_stmt = $pdo->prepare("
    SELECT u.id, COALESCE(u.name, u.full_name, u.email) AS name, u.department 
    FROM meeting_attendees ma
    JOIN users u ON ma.user_id = u.id
    WHERE ma.meeting_id = :id
");
$att_stmt->execute([':id' => $meeting_id]);
$attendees = $att_stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Meeting | Meeting Planner</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>
:root {
  --primary-color: #7b6ef6;
  --primary-light: #a58bff;
  --border-color: #e4e2f5;
  --text-primary: #1a1c2b;
  --text-secondary: #7c7b91;
  --shadow-md: 0 8px 30px rgba(123,110,246,0.15);
  --radius: 14px;
}

body {
  font-family: 'Inter', sans-serif;
  background: linear-gradient(135deg, #f4f1ff, #f9f7ff);
  color: var(--text-primary);
  min-height: 100vh;
  padding: 50px 15px;
}

/* Card */
.view-card {
  background: #fff;
  border-radius: var(--radius);
  border: 1px solid var(--border-color);
  box-shadow: var(--shadow-md);
  max-width: 900px;
  margin: auto;
  padding: 2.5rem;
  position: relative;
  transition: all 0.3s ease;
}
.view-card::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 5px;
  background: linear-gradient(90deg, var(--primary-color), var(--primary-light));
  border-top-left-radius: var(--radius);
  border-top-right-radius: var(--radius);
}

/* Header */
.view-header {
  text-align: center;
  margin-bottom: 2rem;
}
.view-header h2 {
  font-weight: 600;
  color: var(--primary-color);
}
.view-header p {
  color: var(--text-secondary);
}
.view-header i {
  color: var(--primary-color);
  text-shadow: 0 0 10px rgba(123,110,246,0.5);
}

/* Details */
.detail-label {
  font-weight: 600;
  color: var(--text-primary);
  font-size: 0.9rem;
  margin-bottom: 0.3rem;
  display: flex;
  align-items: center;
  gap: 6px;
}
.detail-label i {
  color: var(--primary-color);
}
.detail-value {
  background: #fff;
  border: 1.5px solid var(--border-color);
  border-radius: var(--radius);
  padding: 0.7rem 1rem;
  color: var(--text-primary);
  margin-bottom: 1rem;
  font-size: 0.95rem;
  box-shadow: inset 0 0 10px rgba(123,110,246,0.05);
}

/* Attendees */
.attendee-pill {
  background: #efe9ff;
  color: var(--primary-color);
  border-radius: 16px;
  padding: 6px 14px;
  display: inline-block;
  margin: 4px;
  font-size: 0.9rem;
  font-weight: 500;
}

/* Buttons */
.btn-primary {
  background: linear-gradient(90deg, var(--primary-color), var(--primary-light));
  border: none;
  border-radius: var(--radius);
  padding: 10px 25px;
  font-weight: 600;
}
.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 18px rgba(123,110,246,0.3);
}
.btn-outline-secondary {
  border-radius: var(--radius);
  font-weight: 500;
}
.btn-outline-secondary:hover {
  background: #f3f0ff;
}

/* Alert */
.alert-danger {
  border-radius: var(--radius);
  background: #fff1f2;
  color: #b91c1c;
  border: 1px solid #fecaca;
  font-weight: 500;
  padding: 1rem;
  box-shadow: var(--shadow-md);
}
</style>
</head>
<body>

<div class="view-card">
  <div class="view-header">
    <div class="mb-3">
      <i class="bi bi-eye-fill fs-1"></i>
    </div>
    <h2><i class="bi bi-calendar-event me-2"></i>Meeting Details</h2>
    <p>All details for the selected meeting</p>
  </div>

  <?php if (!$meeting): ?>
    <div class="alert alert-danger text-center">
      <i class="bi bi-exclamation-triangle me-2"></i> Meeting not found or invalid ID!
    </div>
  <?php else: ?>

  <div class="row g-3">
    <div class="col-md-6">
      <div class="detail-label"><i class="bi bi-card-heading"></i> Title</div>
      <div class="detail-value"><?= htmlspecialchars($meeting['title']) ?></div>
    </div>
    <div class="col-md-3">
      <div class="detail-label"><i class="bi bi-calendar-date"></i> Date</div>
      <div class="detail-value"><?= htmlspecialchars($meeting['meeting_date']) ?></div>
    </div>
    <div class="col-md-3">
      <div class="detail-label"><i class="bi bi-clock"></i> Time</div>
      <div class="detail-value"><?= htmlspecialchars($meeting['meeting_time']) ?></div>
    </div>
    <div class="col-md-3">
      <div class="detail-label"><i class="bi bi-hourglass-split"></i> Duration</div>
      <div class="detail-value"><?= htmlspecialchars($meeting['duration']) ?> mins</div>
    </div>
    <div class="col-md-3">
      <div class="detail-label"><i class="bi bi-laptop"></i> Mode</div>
      <div class="detail-value"><?= htmlspecialchars($meeting['mode']) ?></div>
    </div>
    <div class="col-md-6">
      <div class="detail-label"><i class="bi bi-geo-alt"></i> Location / Link</div>
      <div class="detail-value"><?= htmlspecialchars($meeting['location'] ?: '—') ?></div>
    </div>
    <div class="col-md-6">
      <div class="detail-label"><i class="bi bi-building"></i> Department</div>
      <div class="detail-value"><?= htmlspecialchars($meeting['department'] ?: '—') ?></div>
    </div>
    <div class="col-12">
      <div class="detail-label"><i class="bi bi-journal-text"></i> Agenda</div>
      <div class="detail-value"><?= nl2br(htmlspecialchars($meeting['agenda'] ?: 'No agenda provided')) ?></div>
    </div>
    <div class="col-12">
      <div class="detail-label"><i class="bi bi-people"></i> Attendees</div>
      <?php if (count($attendees) > 0): ?>
        <div>
          <?php foreach ($attendees as $a): ?>
            <span class="attendee-pill">
              <?= htmlspecialchars($a['name']) ?>
              <?= $a['department'] ? " ({$a['department']})" : "" ?>
            </span>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="detail-value">No attendees assigned</div>
      <?php endif; ?>
    </div>
    <?php if (!empty($meeting['file_path'])): ?>
      <div class="col-12">
        <div class="detail-label"><i class="bi bi-paperclip"></i> Attached File</div>
        <a href="../<?= htmlspecialchars($meeting['file_path']) ?>" target="_blank" class="btn btn-outline-secondary btn-sm">
          <i class="bi bi-download me-1"></i> View / Download
        </a>
      </div>
    <?php endif; ?>
  </div>

  <div class="mt-4 text-center">
    <a href="meeting_list.php" class="btn btn-outline-secondary me-2">
      <i class="bi bi-arrow-left me-2"></i>Back to List
    </a>
    <a href="edit_meeting.php?id=<?= $meeting_id ?>" class="btn btn-primary">
      <i class="bi bi-pencil-square me-2"></i>Edit Meeting
    </a>
  </div>

  <?php endif; ?>
</div>

</body>
</html>
