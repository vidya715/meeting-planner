<?php
require __DIR__ . '/../includes/config.php';
$active='attendance'; $page_title='Mark Attendance';
include __DIR__.'/../includes/header.php';

$m = $conn->query("SELECT id,title,meeting_date,meeting_time FROM meetings ORDER BY meeting_date DESC, meeting_time DESC");
$mid = isset($_GET['meeting_id'])?(int)$_GET['meeting_id']:0;

$attendees = [];
if ($mid) {
  $stmt = $conn->prepare("SELECT u.id,u.email,COALESCE(u.name,u.full_name,u.email) label, u.department
                          FROM meeting_attendees ma JOIN users u ON u.id=ma.user_id
                          WHERE ma.meeting_id=? ORDER BY u.department,label");
  $stmt->bind_param("i",$mid); $stmt->execute(); $attendees=$stmt->get_result();
}
?>
<div class="card-soft p-4">
  <h3 class="mb-3"><i class="bi bi-clipboard-check text-warning me-2"></i>Mark Attendance</h3>

  <form class="row g-3 mb-3" method="get">
    <div class="col-md-8">
      <label class="form-label">Select Meeting</label>
      <select name="meeting_id" class="form-select" required>
        <option value="">— choose —</option>
        <?php while($row=$m->fetch_assoc()): $t=$row['title'].' ('.$row['meeting_date'].' '.$row['meeting_time'].')'; ?>
          <option value="<?= (int)$row['id'] ?>" <?= $mid==$row['id']?'selected':'' ?>><?= htmlspecialchars($t) ?></option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="col-md-4 d-flex align-items-end">
      <button class="btn btn-gold w-100"><i class="bi bi-arrow-right-circle me-1"></i>Load Attendees</button>
    </div>
  </form>

  <?php if($mid && $attendees instanceof mysqli_result): ?>
  <form method="post" action="/Meeting_Planner/actions/save_attendance.php" class="mt-3">
    <input type="hidden" name="meeting_id" value="<?= (int)$mid ?>">
    <div class="table-responsive">
      <table class="table align-middle">
        <thead><tr><th>Attendee</th><th>Department</th><th class="text-center">Present</th><th class="text-center">Absent</th></tr></thead>
        <tbody>
          <?php while($u=$attendees->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($u['label']) ?><div class="small text-muted"><?= htmlspecialchars($u['email']) ?></div></td>
            <td><span class="badge badge-gold"><?= htmlspecialchars($u['department'] ?: '—') ?></span></td>
            <td class="text-center"><input type="radio" name="status[<?= (int)$u['id'] ?>]" value="PRESENT" required></td>
            <td class="text-center"><input type="radio" name="status[<?= (int)$u['id'] ?>]" value="ABSENT"></td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
    <div class="text-end">
      <button class="btn btn-gold"><i class="bi bi-cloud-check me-1"></i>Save Attendance</button>
    </div>
  </form>
  <?php endif; ?>
</div>
<?php include __DIR__.'/../includes/footer.php'; ?>
