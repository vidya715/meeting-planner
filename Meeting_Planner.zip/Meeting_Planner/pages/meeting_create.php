<?php
require __DIR__ . '/../includes/config.php';
session_start();

/* ---------- FETCH USERS (PDO ONLY) ---------- */
$stmt = $pdo->prepare("
    SELECT 
        id, 
        COALESCE(name, full_name, email) AS label, 
        department
    FROM users
    ORDER BY department, label
");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

$success = isset($_GET['ok']) && $_GET['ok'] == 1;
$meeting_id = (int)($_GET['id'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create Meeting | Meeting Planner</title>

<!-- Bootstrap + Icons + Select2 -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">

<style>
:root {
  --primary-color: #7b6ef6;
  --primary-light: #a58bff;
  --accent-bg: #f7f5ff;
  --border-color: #e4e2f5;
  --text-primary: #1a1c2b;
  --text-secondary: #7c7b91;
  --radius: 14px;
  --shadow-md: 0 8px 24px rgba(123,110,246,0.15);
}

body {
  font-family: 'Inter', sans-serif;
  background: linear-gradient(135deg, #f1edff, #f7f5ff);
  margin: 0;
  min-height: 100vh;
}

/* SIDEBAR OFFSET */
.page-wrapper {
  margin-left: 260px;
  padding: 40px 20px;
}
@media (max-width: 992px) {
  .page-wrapper { margin-left: 0; }
}

/* CARD */
.card {
  background: #fff;
  border-radius: var(--radius);
  box-shadow: var(--shadow-md);
  border: none;
  padding: 2.5rem;
  position: relative;
}

.card::before {
  content: "";
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 5px;
  background: linear-gradient(90deg, var(--primary-color), var(--primary-light));
  border-top-left-radius: var(--radius);
  border-top-right-radius: var(--radius);
}

/* HEADER */
.header-section {
  text-align: center;
  margin-bottom: 1.8rem;
}

h2.title {
  font-weight: 600;
  font-size: 1.75rem;
  color: var(--primary-color);
}

.subtext {
  color: var(--text-secondary);
  font-size: 0.9rem;
}

/* FORM */
.form-label {
  font-weight: 600;
  font-size: 0.9rem;
  display: flex;
  align-items: center;
  gap: 6px;
}
.form-label i {
  color: var(--primary-color);
}

.form-control,
.form-select {
  border-radius: var(--radius);
  border: 1.5px solid var(--border-color);
  padding: 0.6rem 0.9rem;
  font-size: 0.9rem;
}

.form-control:focus,
.form-select:focus {
  border-color: var(--primary-color);
  box-shadow: 0 0 0 4px rgba(123,110,246,0.15);
}

/* SELECT2 */
.select2-selection {
  border-radius: var(--radius) !important;
  border: 1.5px solid var(--border-color) !important;
  min-height: 42px;
}

/* BUTTON */
.btn-primary {
  background: linear-gradient(90deg, var(--primary-color), var(--primary-light));
  border: none;
  border-radius: var(--radius);
  font-weight: 600;
}
.btn-primary:hover {
  transform: translateY(-2px);
}

/* ALERT */
.alert-success {
  background: #edfdf5;
  border: 1px solid #baf3d3;
  color: #036e47;
  border-radius: var(--radius);
}

/* FOOTER */
.footer-note {
  text-align: center;
  margin-top: 2rem;
  padding-top: 1.2rem;
  border-top: 1px solid var(--border-color);
  color: var(--text-secondary);
  font-size: 0.85rem;
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<?php include __DIR__ . '/../includes/sidebar.php'; ?>

<div class="page-wrapper">
  <div class="container">
    <div class="card">

      <div class="header-section">
        <h2 class="title"><i class="bi bi-calendar-plus"></i> Create Meeting</h2>
        <p class="subtext">Plan and schedule your meeting efficiently</p>

        <?php if ($success): ?>
          <div class="alert alert-success mt-3">
            <strong>Meeting created successfully</strong><br>
            <small>Meeting ID: <?= htmlspecialchars($meeting_id) ?></small>
          </div>
        <?php endif; ?>
      </div>

      <form method="post" action="../actions/save_meeting.php" enctype="multipart/form-data">

        <div class="row g-3">

          <div class="col-md-6">
            <label class="form-label"><i class="bi bi-card-heading"></i>Meeting Title</label>
            <input type="text" name="title" class="form-control" required>
          </div>

          <div class="col-md-3">
            <label class="form-label"><i class="bi bi-calendar-event"></i>Date</label>
            <input type="date" name="meeting_date" class="form-control" required min="<?= date('Y-m-d') ?>">
          </div>

          <div class="col-md-3">
            <label class="form-label"><i class="bi bi-clock"></i>Time</label>
            <input type="time" name="meeting_time" class="form-control" required>
          </div>

          <div class="col-md-3">
            <label class="form-label"><i class="bi bi-hourglass-split"></i>Duration (minutes)</label>
            <input type="number" name="duration" class="form-control" min="5" max="480" required>
          </div>

          <div class="col-md-3">
            <label class="form-label"><i class="bi bi-laptop"></i>Mode</label>
            <select name="mode" class="form-select">
              <option value="ONLINE">Online</option>
              <option value="OFFLINE">Offline</option>
              <option value="HYBRID">Hybrid</option>
            </select>
          </div>

          <div class="col-md-6">
            <label class="form-label"><i class="bi bi-geo-alt"></i>Location / Link</label>
            <input name="location" class="form-control">
          </div>

          <div class="col-md-6">
            <label class="form-label"><i class="bi bi-building"></i>Department</label>
            <input name="department" class="form-control">
          </div>

          <div class="col-12">
            <label class="form-label"><i class="bi bi-journal-text"></i>Agenda</label>
            <textarea name="agenda" class="form-control" rows="3"></textarea>
          </div>

          <div class="col-12">
            <label class="form-label"><i class="bi bi-people-fill"></i>Attendees</label>
            <select name="attendees[]" id="attendees" class="form-control" multiple required>
              <?php foreach ($users as $u): ?>
                <option value="<?= (int)$u['id'] ?>">
                  <?= htmlspecialchars($u['label']) ?> (<?= htmlspecialchars($u['department'] ?? '—') ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-md-6">
            <label class="form-label"><i class="bi bi-paperclip"></i>Attach File</label>
            <input type="file" name="file" class="form-control">
          </div>

          <div class="col-md-6">
            <label class="form-label"><i class="bi bi-flag"></i>Priority</label>
            <select name="priority" class="form-select">
              <option value="NORMAL">Normal</option>
              <option value="HIGH">High</option>
              <option value="URGENT">Urgent</option>
            </select>
          </div>

        </div>

        <div class="text-center mt-4">
          <button type="submit" class="btn btn-primary px-4 py-2">
            <i class="bi bi-calendar-check me-2"></i>Create Meeting
          </button>
        </div>
      </form>

      <div class="footer-note">
        © <?= date('Y') ?> Meeting Planner • The Compilers
      </div>

    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$('#attendees').select2({
  placeholder: "Search and select attendees",
  closeOnSelect: false,
  width: '100%'
});
</script>

</body>
</html>
