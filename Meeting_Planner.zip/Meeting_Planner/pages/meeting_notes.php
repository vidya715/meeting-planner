<?php
require __DIR__ . '/../includes/config.php';
$active='notes'; $page_title='Meeting Notes';
include __DIR__.'/../includes/header.php';

$mid = isset($_GET['meeting_id'])?(int)$_GET['meeting_id']:0;
$meetings = $conn->query("SELECT id,title FROM meetings ORDER BY meeting_date DESC");

$notes=[];
if($mid){
  $s=$conn->prepare("SELECT n.id,n.content,n.created_at, COALESCE(u.name,u.full_name,u.email) author
                     FROM notes n LEFT JOIN users u ON u.id=n.user_id
                     WHERE n.meeting_id=? ORDER BY n.created_at DESC");
  $s->bind_param("i",$mid); $s->execute(); $notes=$s->get_result();
}
?>
<div class="card-soft p-4">
  <h3 class="mb-3"><i class="bi bi-journal-text text-warning me-2"></i>Meeting Notes</h3>

  <form class="row g-3 mb-3" method="get">
    <div class="col-md-9">
      <label class="form-label">Select Meeting</label>
      <select name="meeting_id" class="form-select" required>
        <option value="">— choose —</option>
        <?php while($m=$meetings->fetch_assoc()): ?>
          <option value="<?= (int)$m['id']?>" <?= $mid==$m['id']?'selected':''?>><?= htmlspecialchars($m['title'])?></option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="col-md-3 d-flex align-items-end"><button class="btn btn-gold w-100">Open</button></div>
  </form>

  <?php if($mid): ?>
  <form method="post" action="/Meeting_Planner/actions/save_note.php" class="mb-4">
    <input type="hidden" name="meeting_id" value="<?= (int)$mid ?>">
    <label class="form-label">Add Note</label>
    <textarea name="content" class="form-control" rows="3" required placeholder="Summary, decisions, action items..."></textarea>
    <div class="text-end mt-2">
      <button class="btn btn-gold"><i class="bi bi-plus-circle me-1"></i>Add Note</button>
    </div>
  </form>

  <div class="list-group">
    <?php if($notes instanceof mysqli_result && $notes->num_rows): while($n=$notes->fetch_assoc()): ?>
      <div class="list-group-item">
        <div class="d-flex justify-content-between">
          <div class="fw-semibold"><?= htmlspecialchars($n['author'] ?: 'Unknown') ?></div>
          <div class="text-muted small"><?= htmlspecialchars($n['created_at']) ?></div>
        </div>
        <div class="mt-1"><?= nl2br(htmlspecialchars($n['content'])) ?></div>
      </div>
    <?php endwhile; else: ?>
      <div class="text-muted">No notes yet.</div>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</div>
<?php include __DIR__.'/../includes/footer.php'; ?>
