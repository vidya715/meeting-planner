<?php
require __DIR__ . '/../includes/config.php';
session_start();

$meeting_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

/* FETCH MEETING */
$stmt = $pdo->prepare("SELECT * FROM meetings WHERE id = :id");
$stmt->execute([':id' => $meeting_id]);
$meeting = $stmt->fetch(PDO::FETCH_ASSOC);

/* FETCH USERS */
$user_stmt = $pdo->query("SELECT id, COALESCE(name, full_name, email) AS label, department FROM users ORDER BY department, label");
$users = $user_stmt->fetchAll(PDO::FETCH_ASSOC);

/* FETCH ATTENDEES */
$attendee_stmt = $pdo->prepare("SELECT user_id FROM meeting_attendees WHERE meeting_id = :mid");
$attendee_stmt->execute([':mid' => $meeting_id]);
$current_attendees = array_column($attendee_stmt->fetchAll(PDO::FETCH_ASSOC), 'user_id');

$role = strtoupper($_SESSION['user']['role'] ?? 'ORGANISER');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Meeting | Meeting Planner</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/@ttskch/select2-bootstrap4-theme@1.6.2/dist/select2-bootstrap4.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

<style>
body {
  margin: 0;
  font-family: 'Inter', sans-serif;
  background: linear-gradient(135deg,#f1edff,#f7f5ff);
}

.main-content {
  margin-left: 260px;
  padding: 40px 20px;
}

.edit-card {
  background: #fff;
  border-radius: 16px;
  border: 1px solid #e4e2f5;
  box-shadow: 0 10px 32px rgba(123,110,246,0.18);
  max-width: 900px;
  margin: auto;
  padding: 2.8rem;
  position: relative;
}

.edit-card::before {
  content: "";
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 5px;
  background: linear-gradient(90deg,#7b6ef6,#a58bff);
}

.form-label {
  font-weight: 600;
  font-size: .9rem;
  color: #4c3fbf;
  display: flex;
  align-items: center;
  gap: 6px;
}

.form-label i {
  color: #7b6ef6;
}

.form-control, .form-select {
  border-radius: 14px;
  border: 1.5px solid #e4e2f5;
}

.form-control:focus, .form-select:focus {
  border-color: #7b6ef6;
  box-shadow: 0 0 0 4px rgba(123,110,246,.15);
}

.btn-primary {
  background: linear-gradient(90deg,#7b6ef6,#a58bff);
  border: none;
  border-radius: 14px;
  font-weight: 600;
}

.btn-primary:hover {
  transform: translateY(-2px);
}

.btn-outline-secondary {
  border-radius: 14px;
}
</style>
</head>

<body>

<?php include __DIR__ . '/../includes/sidebar.php'; ?>

<div class="main-content">
<div class="edit-card">

<div class="text-center mb-4">
  <i class="bi bi-pencil-square fs-1 text-primary"></i>
  <h2 class="mt-2 fw-bold">Edit Meeting</h2>
  <p class="text-muted">Update your meeting details below</p>
</div>

<?php if (!$meeting): ?>
  <div class="alert alert-danger text-center">Meeting not found!</div>
<?php else: ?>

<?php if (isset($_GET['ok'])): ?>
  <div class="alert alert-success text-center">
    <i class="bi bi-check-circle-fill me-1"></i>
    Meeting updated successfully!
  </div>
<?php endif; ?>

<form method="post" action="../actions/update_meeting.php" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?= htmlspecialchars($meeting['id']) ?>">

<div class="row g-4">

<div class="col-md-6">
  <label class="form-label"><i class="bi bi-card-heading"></i> Title</label>
  <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($meeting['title']) ?>" required>
</div>

<div class="col-md-3">
  <label class="form-label"><i class="bi bi-calendar-event"></i> Date</label>
  <input type="date" name="meeting_date" class="form-control" value="<?= htmlspecialchars($meeting['meeting_date']) ?>" required>
</div>

<div class="col-md-3">
  <label class="form-label"><i class="bi bi-clock"></i> Time</label>
  <input type="time" name="meeting_time" class="form-control" value="<?= htmlspecialchars($meeting['meeting_time']) ?>" required>
</div>

<div class="col-md-3">
  <label class="form-label"><i class="bi bi-hourglass-split"></i> Duration</label>
  <input type="number" name="duration" class="form-control" value="<?= htmlspecialchars($meeting['duration']) ?>" required>
</div>

<div class="col-md-3">
  <label class="form-label"><i class="bi bi-laptop"></i> Mode</label>
  <select name="mode" class="form-select">
    <option value="ONLINE" <?= $meeting['mode']=='ONLINE'?'selected':'' ?>>Online</option>
    <option value="OFFLINE" <?= $meeting['mode']=='OFFLINE'?'selected':'' ?>>Offline</option>
    <option value="HYBRID" <?= $meeting['mode']=='HYBRID'?'selected':'' ?>>Hybrid</option>
  </select>
</div>

<div class="col-md-6">
  <label class="form-label"><i class="bi bi-geo-alt"></i> Location / Link</label>
  <input type="text" name="location" class="form-control" value="<?= htmlspecialchars($meeting['location']) ?>">
</div>

<div class="col-md-6">
  <label class="form-label"><i class="bi bi-building"></i> Department</label>
  <input type="text" name="department" class="form-control" value="<?= htmlspecialchars($meeting['department']) ?>">
</div>

<div class="col-12">
  <label class="form-label"><i class="bi bi-journal-text"></i> Agenda</label>
  <textarea name="agenda" rows="3" class="form-control"><?= htmlspecialchars($meeting['agenda']) ?></textarea>
</div>

<div class="col-12">
  <label class="form-label"><i class="bi bi-people-fill"></i> Attendees</label>
  <select name="attendees[]" id="attendees" class="form-control select2" multiple>
    <?php foreach ($users as $u): ?>
      <option value="<?= (int)$u['id'] ?>" <?= in_array($u['id'], $current_attendees)?'selected':'' ?>>
        <?= htmlspecialchars($u['label']) ?> <?= $u['department'] ? "({$u['department']})" : "" ?>
      </option>
    <?php endforeach; ?>
  </select>
</div>

<div class="col-12">
  <label class="form-label"><i class="bi bi-paperclip"></i> Upload New File</label>
  <input type="file" name="file" class="form-control">
</div>

</div>

<div class="mt-4 d-flex justify-content-between">
  <a href="meeting_list.php" class="btn btn-outline-secondary">
    <i class="bi bi-arrow-left me-1"></i> Cancel
  </a>
  <button type="submit" class="btn btn-primary">
    <i class="bi bi-save me-1"></i> Update Meeting
  </button>
</div>
</form>

<?php endif; ?>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(document).ready(function () {
  $('#attendees').select2({
    theme: 'bootstrap4',
    width: '100%'
  });
});
</script>

</body>
</html>
