<?php
require __DIR__ . '/../includes/config.php';
session_start();

// ✅ Optional: restrict access
// if (!isset($_SESSION['user'])) {
//     header("Location: ../login.php");
//     exit;
// }

// ✅ Filters
$filter = $_GET['filter'] ?? 'ALL';
$search = trim($_GET['search'] ?? '');

// ✅ Build dynamic query (PDO)
$query = "SELECT * FROM meetings WHERE 1=1";
$params = [];

if ($filter !== 'ALL') {
    $query .= " AND mode = :mode";
    $params[':mode'] = $filter;
}

if (!empty($search)) {
    $query .= " AND title LIKE :search";
    $params[':search'] = "%$search%";
}

// ✅ Prepare & execute query
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$meetings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ✅ Stats (using PDO fetchColumn)
$totalMeetings  = $pdo->query("SELECT COUNT(*) FROM meetings")->fetchColumn();
$totalOnline    = $pdo->query("SELECT COUNT(*) FROM meetings WHERE mode='ONLINE'")->fetchColumn();
$totalOffline   = $pdo->query("SELECT COUNT(*) FROM meetings WHERE mode='OFFLINE'")->fetchColumn();
$totalAttendees = $pdo->query("SELECT COUNT(*) FROM meeting_attendees")->fetchColumn();

// Get user role for sidebar
$role = isset($_SESSION['user']) ? strtoupper($_SESSION['user']['role']) : 'GUEST';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Meetings | Meeting Planner</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>
:root {
  --primary-color: #7b6ef6;
  --primary-light: #a58bff;
  --accent-bg: #f7f5ff;
  --border-color: #e4e2f5;
  --text-primary: #1a1c2b;
  --text-secondary: #7c7b91;
  --shadow: 0 6px 16px rgba(123,110,246,0.15);
  --radius: 14px;
}

body {
  font-family: 'Inter', sans-serif;
  background: linear-gradient(135deg, #f1edff, #f7f5ff);
  color: var(--text-primary);
  padding: 40px 15px;
  transition: margin-left 0.35s ease;
}

body.sidebar-open {
  margin-left: 260px;
}

/* ================= HAMBURGER MENU ================= */
.hamburger-menu {
    position: fixed;
    top: 20px;
    left: 20px;
    z-index: 1100;
    background: linear-gradient(90deg, var(--primary-color), var(--primary-light));
    width: 50px;
    height: 50px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: 0 4px 15px rgba(123,110,246,0.3);
    color: white;
    font-size: 1.5rem;
    transition: all 0.3s ease;
}

.hamburger-menu:hover {
    transform: scale(1.05);
    box-shadow: 0 6px 20px rgba(123,110,246,0.4);
}

/* ================= SIDEBAR ================= */
.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 260px;
    height: 100vh;
    background: linear-gradient(180deg, #060D2A, #020617);
    color: #fff;
    padding-top: 1rem;
    box-shadow: 6px 0 30px rgba(0,0,0,0.45);
    transform: translateX(-100%);
    transition: transform 0.35s ease;
    z-index: 1200;
}

/* SHOW SIDEBAR ONLY WHEN OPEN */
.sidebar.open {
    transform: translateX(0);
}

/* HEADER */
.sidebar-header {
    text-align: center;
    padding: 1.6rem 1rem;
    border-bottom: 1px solid rgba(255,255,255,0.15);
}

.sidebar-header h5 {
    margin: 0;
    font-weight: 700;
    font-size: 1.3rem;
}

.sidebar-header small {
    font-size: 0.75rem;
    letter-spacing: 1px;
    opacity: 0.85;
}

/* MENU */
.sidebar-menu {
    list-style: none;
    padding: 0;
    margin: 1rem 0;
}

.sidebar-menu li {
    margin: 0.35rem 0;
}

.sidebar-menu a {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 0.8rem 1.6rem;
    color: #e5e7eb;
    text-decoration: none;
    font-size: 0.95rem;
    border-radius: 10px;
    margin: 0 10px;
    transition: all 0.25s ease;
}

/* ICON */
.sidebar-menu i {
    width: 20px;
    text-align: center;
    font-size: 1rem;
    color: #c7d2fe;
}

/* HOVER EFFECT */
.sidebar-menu a:hover {
    background: #7c7cf8;
    color: #ffffff;
    box-shadow: 0 6px 16px rgba(124,124,248,0.45);
}

.sidebar-menu a:hover i {
    color: #ffffff;
}

/* ACTIVE MENU */
.sidebar-menu a.active {
    background: #7c7cf8;
    color: #ffffff;
    box-shadow: 0 6px 16px rgba(124,124,248,0.45);
}

.sidebar-menu a.active i {
    color: #ffffff;
}

/* LOGOUT */
.sidebar-menu .logout a {
    margin-top: 1.2rem;
    background: rgba(239,68,68,0.08);
}

.sidebar-menu .logout a:hover {
    background: rgba(239,68,68,0.25);
    box-shadow: 0 6px 16px rgba(239,68,68,0.45);
}

/* Header Section */
.header-section {
  background: linear-gradient(90deg, var(--primary-color), var(--primary-light));
  color: white;
  border-radius: var(--radius);
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(123,110,246,0.2);
  text-align: center;
}
.header-section h2 {
  font-weight: 600;
}
.header-section p {
  opacity: 0.9;
  margin-bottom: 0;
}

/* Stats Cards */
.stat-card {
  background: #fff;
  border-radius: var(--radius);
  border: 1px solid var(--border-color);
  padding: 1rem;
  box-shadow: var(--shadow);
  transition: 0.25s ease;
  text-align: center;
}
.stat-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 25px rgba(123,110,246,0.2);
}
.stat-card h3 {
  color: var(--primary-color);
  font-weight: 700;
}

/* Filter Buttons */
.filter-btn {
  border: 1.5px solid var(--border-color);
  background: #fff;
  padding: 8px 16px;
  border-radius: 10px;
  font-weight: 500;
  color: var(--text-primary);
  transition: 0.2s;
}
.filter-btn.active {
  background: linear-gradient(90deg, var(--primary-color), var(--primary-light));
  color: white;
  border-color: transparent;
  box-shadow: var(--shadow);
}

/* Meeting Cards */
.meeting-card {
  background: #fff;
  border-radius: var(--radius);
  border: 1px solid var(--border-color);
  box-shadow: var(--shadow);
  transition: 0.25s ease;
  padding: 1.5rem;
}
.meeting-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 10px 25px rgba(123,110,246,0.25);
}
.meeting-card h5 {
  font-weight: 600;
  color: var(--primary-color);
}
.meeting-card small {
  color: var(--text-secondary);
}

/* Badges */
.badge-online {
  background: rgba(37,211,102,0.1);
  color: #10b981;
  border: 1px solid rgba(16,185,129,0.2);
}
.badge-offline {
  background: rgba(155,135,255,0.1);
  color: var(--primary-color);
  border: 1px solid rgba(155,135,255,0.3);
}

/* Buttons */
.btn-primary {
  background: linear-gradient(90deg, var(--primary-color), var(--primary-light));
  border: none;
  border-radius: var(--radius);
  font-weight: 600;
}
.btn-primary:hover {
  box-shadow: var(--shadow);
  transform: translateY(-2px);
}
.btn-outline-primary, .btn-outline-secondary {
  border-radius: var(--radius);
}

/* Empty State */
.empty-state {
  background: #fff;
  border: 2px dashed var(--border-color);
  border-radius: var(--radius);
  text-align: center;
  padding: 3rem 2rem;
  color: var(--text-secondary);
  box-shadow: var(--shadow);
}
.empty-state i {
  color: var(--primary-color);
  opacity: 0.6;
}

/* Success Alert */
.alert-success {
  border-radius: var(--radius);
  background: #edfdf5;
  color: #036e47;
  border: 1px solid #a7f3d0;
  font-weight: 500;
  padding: 1rem;
  animation: fadeIn 0.4s ease;
}
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(-10px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
</head>
<body>

<!-- ================= HAMBURGER MENU ================= -->
<div class="hamburger-menu" id="hamburger">
    <i class="fas fa-bars"></i>
</div>

<!-- ================= SIDEBAR ================= -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <h5>Meeting Planner</h5>
        <small><?= htmlspecialchars($role) ?></small>
    </div>

    <ul class="sidebar-menu">
        <li>
            <a href="/Meeting_Planner/dashboard.php">
                <i class="fas fa-home"></i> Dashboard
            </a>
        </li>

        <?php if ($role === 'ORGANISER'): ?>
            <li><a href="/Meeting_Planner/pages/meeting_create.php"><i class="fas fa-calendar-plus"></i> Create Meeting</a></li>
            <li><a href="/Meeting_Planner/pages/meeting_list.php" class="active"><i class="fas fa-calendar-check"></i> Manage Meetings</a></li>
            <li><a href="/Meeting_Planner/pages/Attendance_form.php"><i class="fas fa-user-check"></i> Mark Attendance</a></li>
            <li><a href="/Meeting_Planner/pages/mom_notes.php"><i class="fas fa-sticky-note"></i> Meeting Notes</a></li>
            <li><a href="/Meeting_Planner/pages/assign-task.php"><i class="fas fa-tasks"></i> Assign Tasks</a></li>
            <li><a href="/Meeting_Planner/pages/task_report.php"><i class="fas fa-clipboard-list"></i> Review Tasks</a></li>
        
        <?php elseif ($role === 'EMPLOYEE'): ?>
            <li><a href="/Meeting_Planner/pages/meeting_list.php" class="active"><i class="fas fa-calendar-check"></i> My Meetings</a></li>
            <li><a href="/Meeting_Planner/pages/task_report.php"><i class="fas fa-clipboard-list"></i> My Tasks</a></li>
        
        <?php elseif ($role === 'COLLECTOR'): ?>
            <li><a href="/Meeting_Planner/pages/meeting_list.php" class="active"><i class="fas fa-calendar-check"></i> All Meetings</a></li>
            <li><a href="/Meeting_Planner/pages/task_report.php"><i class="fas fa-clipboard-list"></i> Task Progress</a></li>
        <?php endif; ?>

        <li class="logout">
            <a href="/Meeting_Planner/dashboard.php?action=logout">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </li>
    </ul>
</div>

<div class="container py-4">

  <!-- Header -->
  <div class="header-section mb-5">
    <h2><i class="bi bi-calendar-week me-2"></i>Manage Meetings</h2>
    <p>View, search, and manage all your meetings efficiently</p>
  </div>

  <!-- Success Alert -->
  <?php if (isset($_GET['updated'])): ?>
    <div class="alert alert-success text-center fw-semibold rounded-3 mb-4" id="updateAlert">
      <i class="bi bi-check-circle me-1"></i> Meeting updated successfully!
    </div>
    <script>
      setTimeout(() => {
        const alertBox = document.getElementById('updateAlert');
        if (alertBox) {
          alertBox.style.opacity = '0';
          setTimeout(() => alertBox.remove(), 600);
        }
      }, 3000);
    </script>
  <?php endif; ?>

  <!-- Stats -->
  <div class="row g-3 mb-4">
    <div class="col-md-3"><div class="stat-card"><h3><?= $totalMeetings ?></h3><p>Total Meetings</p></div></div>
    <div class="col-md-3"><div class="stat-card"><h3><?= $totalOnline ?></h3><p>Online</p></div></div>
    <div class="col-md-3"><div class="stat-card"><h3><?= $totalOffline ?></h3><p>In-person</p></div></div>
    <div class="col-md-3"><div class="stat-card"><h3><?= $totalAttendees ?></h3><p>Total Attendees</p></div></div>
  </div>

  <!-- Filters -->
  <form method="get" class="d-flex flex-wrap justify-content-between align-items-center mb-4">
    <div class="input-group mb-2" style="max-width:400px;">
      <span class="input-group-text"><i class="bi bi-search"></i></span>
      <input type="text" name="search" class="form-control" value="<?= htmlspecialchars($search) ?>" placeholder="Search by title...">
    </div>

    <div class="btn-group mb-2">
      <?php
      $filters = ['ALL' => 'All', 'ONLINE' => 'Online', 'OFFLINE' => 'In-person'];
      foreach ($filters as $key => $label):
      ?>
      <a href="?filter=<?= $key ?>&search=<?= urlencode($search) ?>"
         class="btn filter-btn <?= $filter === $key ? 'active' : '' ?>"><?= $label ?></a>
      <?php endforeach; ?>
    </div>
  </form>

  <!-- Meeting Cards -->
  <?php if (count($meetings) > 0): ?>
  <div class="row g-4">
    <?php foreach ($meetings as $m): ?>
      <div class="col-lg-4 col-md-6">
        <div class="meeting-card h-100">
          <div class="d-flex justify-content-between align-items-start">
            <div>
              <h5><i class="bi bi-calendar-event me-2"></i><?= htmlspecialchars($m['title']) ?></h5>
              <span class="badge <?= $m['mode'] === 'ONLINE' ? 'badge-online' : 'badge-offline' ?>">
                <?= htmlspecialchars($m['mode']) ?>
              </span>
              <?php if (!empty($m['department'])): ?>
                <span class="badge bg-light text-dark border ms-1"><?= htmlspecialchars($m['department']) ?></span>
              <?php endif; ?>
            </div>
            <small><?= htmlspecialchars($m['meeting_date']) ?></small>
          </div>

          <div class="mt-3 small">
            <p class="mb-1"><i class="bi bi-clock text-primary me-2"></i><?= htmlspecialchars($m['meeting_time']) ?></p>
            <p class="mb-1"><i class="bi bi-hourglass-split text-primary me-2"></i><?= $m['duration'] ?> mins</p>
            <p class="mb-1"><i class="bi <?= $m['mode'] === 'ONLINE' ? 'bi-link-45deg' : 'bi-geo-alt' ?> text-primary me-2"></i>
              <?= htmlspecialchars($m['location'] ?: '—') ?>
            </p>
            <p class="text-muted mt-2"><i class="bi bi-card-checklist me-2"></i><?= htmlspecialchars($m['agenda'] ?: 'No agenda') ?></p>
          </div>

          <div class="mt-3 d-flex justify-content-between">
            <a href="view_meeting.php?id=<?= $m['id'] ?>" class="btn btn-outline-primary btn-sm">
              <i class="bi bi-eye me-1"></i> View
            </a>
            <?php if ($role === 'ORGANISER'): ?>
              <a href="edit_meeting.php?id=<?= $m['id'] ?>" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-pencil me-1"></i> Edit
              </a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <?php else: ?>
    <div class="empty-state mt-4">
      <i class="bi bi-calendar-x display-5 mb-3"></i>
      <h5>No meetings found</h5>
      <p class="mb-3"><?= $search ? "No results for '$search'" : "No meetings yet" ?></p>
      <?php if ($role === 'ORGANISER'): ?>
        <a href="meeting_create.php" class="btn btn-primary"><i class="bi bi-plus-circle me-2"></i>Create Meeting</a>
      <?php endif; ?>
    </div>
  <?php endif; ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const hamburger = document.getElementById("hamburger");
    const sidebar = document.getElementById("sidebar");
    const body = document.body;

    if (hamburger && sidebar) {
        hamburger.addEventListener("click", function () {
            sidebar.classList.toggle("open");
            body.classList.toggle("sidebar-open");
            
            // Change icon
            const icon = hamburger.querySelector('i');
            if (sidebar.classList.contains("open")) {
                icon.className = "fas fa-times";
            } else {
                icon.className = "fas fa-bars";
            }
        });
    }
    
    // Close sidebar when clicking outside
    document.addEventListener('click', function(event) {
        const isClickInsideSidebar = sidebar.contains(event.target);
        const isClickOnHamburger = hamburger.contains(event.target);
        
        if (!isClickInsideSidebar && !isClickOnHamburger && sidebar.classList.contains('open')) {
            sidebar.classList.remove('open');
            body.classList.remove('sidebar-open');
            const icon = hamburger.querySelector('i');
            icon.className = "fas fa-bars";
        }
    });
});
</script>
</body>
</html>