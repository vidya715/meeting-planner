<?php
require __DIR__ . '/../includes/config.php';
$active='review'; $page_title='Review Tasks';
include __DIR__.'/../includes/header.php';

$tasks = $conn->query("SELECT t.id,t.title,t.status,t.priority,t.deadline,
                       COALESCE(u1.name,u1.full_name,u1.email) assignee,
                       COALESCE(u2.name,u2.full_name,u2.email) assigner,
                       m.title mtitle
                       FROM tasks t
                       LEFT JOIN users u1 ON u1.id=t.assigned_to
                       LEFT JOIN users u2 ON u2.id=t.assigned_by
                       LEFT JOIN meetings m ON m.id=t.meeting_id
                       ORDER BY t.created_at DESC");
?>
<div class="card-soft p-4">
  <h3 class="mb-3"><i class="bi bi-clipboard-data text-warning me-2"></i>Review Tasks</h3>

  <div class="table-responsive">
    <table class="table align-middle">
      <thead><tr>
        <th>Task</th><th>Meeting</th><th>Assignee</th><th>Priority</th><th>Deadline</th><th>Status</th><th>Update</th>
      </tr></thead>
      <tbody>
      <?php while($t=$tasks->fetch_assoc()): ?>
        <tr>
          <td class="fw-semibold"><?= htmlspecialchars($t['title']) ?></td>
          <td><?= htmlspecialchars($t['mtitle'] ?: '—') ?></td>
          <td><?= htmlspecialchars($t['assignee'] ?: '—') ?></td>
          <td><span class="badge badge-gold"><?= htmlspecialchars($t['priority']) ?></span></td>
          <td><?= htmlspecialchars($t['deadline'] ?: '—') ?></td>
          <td><?= htmlspecialchars($t['status']) ?></td>
          <td>
            <form class="d-flex gap-2" method="post" action="/Meeting_Planner/actions/save_task_update.php">
              <input type="hidden" name="task_id" value="<?= (int)$t['id'] ?>">
              <select name="status" class="form-select form-select-sm" style="max-width:150px">
                <?php foreach(['OPEN','IN_PROGRESS','BLOCKED','DONE'] as $s): ?>
                  <option <?= $t['status']===$s?'selected':'' ?> value="<?= $s ?>"><?= $s ?></option>
                <?php endforeach; ?>
              </select>
              <input name="comment" class="form-control form-control-sm" placeholder="Comment">
              <button class="btn btn-gold btn-sm"><i class="bi bi-save"></i></button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__.'/../includes/footer.php'; ?>
