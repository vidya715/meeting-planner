<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Task Update</title>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <style>
  /* ==============================
     Elegant Violet-Themed UI
     ============================== */

  * { box-sizing: border-box; }

  :root {
    --primary: #7b6ef6;
    --primary-light: #a78bfa;
    --bg: linear-gradient(135deg, #f5f3ff, #ece9ff);
    --text-dark: #1e1b4b;
    --border: #ddd6fe;
    --radius: 14px;
    --shadow: 0 10px 25px rgba(123,110,246,0.2);
  }

  body {
    margin: 0;
    min-height: 100vh;
    background: var(--bg);
    font-family: "Inter", "Segoe UI", sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 40px 20px;
  }

  .card {
    background: #fff;
    border-radius: var(--radius);
    padding: 2rem 2.4rem;
    box-shadow: var(--shadow);
    width: 500px;
    max-width: 95%;
    border-top: 6px solid var(--primary);
    animation: fadeIn 0.6s ease;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }

  h2 {
    color: var(--primary);
    text-align: center;
    font-weight: 700;
    margin-bottom: 1.4rem;
  }

  label {
    font-weight: 600;
    color: var(--text-dark);
    display: block;
    margin-bottom: .4rem;
  }

  input, select, textarea {
    width: 100%;
    border: 1.5px solid var(--border);
    border-radius: var(--radius);
    padding: .65rem .9rem;
    font-size: .9rem;
    background: #faf9ff;
    transition: 0.2s;
  }

  input:focus, select:focus, textarea:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 4px rgba(123,110,246,0.15);
    outline: none;
  }

  input[readonly] {
    background: #f1f0ff;
    color: #6b6b8f;
  }

  textarea {
    min-height: 100px;
    resize: vertical;
  }

  button {
    width: 100%;
    border: none;
    background: linear-gradient(90deg, var(--primary), var(--primary-light));
    color: white;
    font-weight: 600;
    font-size: 1rem;
    padding: .8rem;
    border-radius: var(--radius);
    margin-top: 1.4rem;
    cursor: pointer;
    box-shadow: 0 6px 15px rgba(123,110,246,0.3);
    transition: all .3s ease;
  }

  button:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(123,110,246,0.4);
  }

  .form-group { margin-bottom: 1rem; }
  </style>
</head>
<body>

<div class="card">
  <h2>Task Update</h2>

  <div class="form-group">
    <label>Task Title</label>
    <input type="text" id="taskTitle" readonly>
  </div>

  <div class="form-group">
    <label>Department</label>
    <input type="text" id="department" readonly>
  </div>

  <div class="form-group">
    <label>Assigned To</label>
    <input type="text" id="assignedTo" readonly>
  </div>

  <div class="form-group">
    <label>Assigned By</label>
    <input type="text" id="assignedBy" readonly>
  </div>

  <div class="form-group">
    <label>Status</label>
    <select id="status">
      <option value="PENDING">PENDING</option>
      <option value="IN_PROGRESS">IN_PROGRESS</option>
      <option value="COMPLETED">COMPLETED</option>
    </select>
  </div>

  <div class="form-group">
    <label>Progress Notes</label>
    <textarea id="notes" placeholder="Add progress notes here..."></textarea>
  </div>

  <div class="form-group">
    <label>Last Updated On</label>
    <input type="text" id="updatedOn" readonly>
  </div>

  <button id="updateBtn">Update Task</button>
</div>

<script>
$(function(){
  const taskId = new URLSearchParams(window.location.search).get("id");
  if(!taskId){ alert("Task ID missing!"); return; }

  const userId = 1; // Replace later with session user id

  // Load Task Details
  $.get("../actions/get_task.php",{task_id:taskId},function(t){
    if(t.error){ alert(t.error); return; }
    $("#taskTitle").val(t.title);
    $("#department").val(t.department);
    $("#assignedTo").val(t.assigned_to_name || "N/A");
    $("#assignedBy").val(t.assigned_by_name || "N/A");
  },"json");

  // Load Latest Update
  $.get("../actions/get_latest_update.php",{task_id:taskId},function(d){
    if(d){
      $("#status").val(d.status || "PENDING");
      $("#notes").val(d.progress_notes || "");
      $("#updatedOn").val(d.updated_on || "Not updated yet");
    }
  },"json");

  // Update Task
  $("#updateBtn").click(function(){
    const payload = {
      taskId: Number(taskId),
      status: $("#status").val(),
      progress_notes: $("#notes").val(),
      updatedBy: userId
    };

    $("#updateBtn").text("Updating...").prop("disabled", true);

    $.ajax({
      url: "../actions/update_task.php",
      method: "POST",
      contentType: "application/json",
      dataType: "json",
      data: JSON.stringify(payload),
      success: function(res){
        $("#updateBtn").text("Update Task").prop("disabled", false);
        if(res.success){
          const now = new Date();
          $("#updatedOn").val(now.toLocaleString());
          alert("✅ Task updated successfully at " + now.toLocaleString());
        } else {
          alert("❌ " + res.error);
        }
      },
      error: function(){
        $("#updateBtn").text("Update Task").prop("disabled", false);
        alert("❌ Server error while updating.");
      }
    });
  });
});
</script>
</body>
</html>
