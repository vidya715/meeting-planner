<?php
require '../includes/config.php';
session_start();

/* ✅ INCLUDE SIDEBAR */
include __DIR__ . '/../includes/sidebar.php';

require '../models/Meeting.php';
require '../models/Note.php';

$departmentColors = [
    "General" => "#64748b",
    "HR" => "#06b6d4",
    "IT" => "#2563eb",
    "Sales" => "#16a34a",
    "Finance" => "#ca8a04"
];

$meetings = Meeting::all($pdo);
$notes    = Note::all($pdo);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Meeting Notes (MoM)</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
/* ================= LAYOUT ================= */
body {
    font-family: "Poppins", sans-serif;
    background: linear-gradient(135deg, #f3e8ff, #f8f5ff);
    min-height: 100vh;
    margin: 0;
    overflow-x: hidden;
}

.page-content {
    margin-left: 260px;
    padding: 50px 40px;
}

/* ================= MAIN CARD ================= */
.main-card {
    max-width: 1200px;
    margin: auto;
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 8px 25px rgba(123,110,246,0.15);
}

/* HEADER */
.header {
    background: linear-gradient(90deg, #7b6ef6, #a58bff);
    color: #fff;
    padding: 25px;
    text-align: center;
    border-top-left-radius: 16px;
    border-top-right-radius: 16px;
}

.section {
    background: #fff;
    border-radius: 14px;
    padding: 25px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    margin-bottom: 25px;
}

/* NOTES */
.note-card {
    background: #fff;
    border-left: 6px solid;
    padding: 18px;
    border-radius: 12px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    margin-bottom: 15px;
}

.note-title {
    font-weight: 700;
    color: #7b6ef6;
}

.note-meta {
    font-size: 13px;
    color: #6b7280;
    margin-bottom: 6px;
}

/* BUTTONS */
.btn {
    border-radius: 10px;
}

.btn-primary {
    background: linear-gradient(90deg, #7b6ef6, #a58bff);
    border: none;
}

.btn-primary:hover {
    box-shadow: 0 4px 15px rgba(123,110,246,0.3);
}

.btn-secondary {
    background: #e5e7eb;
    border: none;
}
</style>
</head>

<body>

<div class="page-content">

    <div class="main-card">

        <div class="header">
            <h2>📋 Minutes of Meeting (MoM)</h2>
            <p class="mb-0 opacity-75">Log discussions & track decisions</p>
        </div>

        <div class="p-4">

            <!-- ================= ADD / EDIT FORM ================= -->
            <div class="section">
                <h5 class="mb-3">✏️ Add / Edit Note</h5>

                <form method="POST" action="../actions/NoteController.php">
                    <input type="hidden" name="action" id="action" value="add">
                    <input type="hidden" name="note_id" id="note_id">

                    <div class="mb-3">
                        <label class="form-label">📅 Meeting</label>
                        <select name="meeting_id" id="meeting_id" class="form-select" required>
                            <option value="">Select Meeting</option>
                            <?php foreach ($meetings as $m): ?>
                                <option value="<?= $m['id'] ?>"><?= htmlspecialchars($m['title']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">📝 Note Title</label>
                        <input type="text" name="title" id="title" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">🏢 Department</label>
                        <select name="department" id="department" class="form-select" required>
                            <?php foreach ($departmentColors as $d => $c): ?>
                                <option value="<?= $d ?>"><?= $d ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">📄 Description</label>
                        <textarea name="description" id="description" class="form-control" rows="4" required></textarea>
                    </div>

                    <button class="btn btn-primary w-100">💾 Save Note</button>
                    <button type="button" class="btn btn-secondary w-100 mt-2" onclick="resetForm()">🔄 Reset</button>
                </form>
            </div>

            <!-- ================= ALL NOTES ================= -->
            <div class="section">
                <h5 class="mb-3">📚 All Notes</h5>

                <?php foreach ($notes as $n): ?>
                    <div class="note-card" style="border-left-color: <?= $departmentColors[$n['department']] ?? '#7b6ef6' ?>">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <div class="note-title"><?= htmlspecialchars($n['title']) ?></div>
                                <div class="note-meta">
                                    Meeting: <strong><?= htmlspecialchars($n['meeting_title']) ?></strong><br>
                                    <?= date('d M Y, H:i', strtotime($n['created_at'])) ?>
                                </div>
                            </div>

                            <div class="d-flex gap-2">
                                <button class="btn btn-sm btn-outline-primary"
                                    onclick="editNote(
                                        <?= $n['id'] ?>,
                                        '<?= addslashes($n['title']) ?>',
                                        <?= $n['meeting_id'] ?>,
                                        '<?= $n['department'] ?>',
                                        '<?= addslashes($n['description']) ?>'
                                    )">
                                    ✏️ Edit
                                </button>

                                <form method="POST" action="../actions/NoteController.php"
                                      onsubmit="return confirm('Delete this note?')">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="note_id" value="<?= $n['id'] ?>">
                                    <button class="btn btn-sm btn-outline-danger">🗑️ Delete</button>
                                </form>
                            </div>
                        </div>

                        <p class="mt-2 mb-0"><?= nl2br(htmlspecialchars($n['description'])) ?></p>
                    </div>
                <?php endforeach; ?>
            </div>

        </div>
    </div>

</div>

<script>
function editNote(id, title, meeting, dept, desc) {
    document.getElementById('action').value = 'update';
    document.getElementById('note_id').value = id;
    document.getElementById('title').value = title;
    document.getElementById('meeting_id').value = meeting;
    document.getElementById('department').value = dept;
    document.getElementById('description').value = desc;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function resetForm() {
    document.getElementById('action').value = 'add';
    document.getElementById('note_id').value = '';
    document.querySelector('form').reset();
}
</script>

</body>
</html>