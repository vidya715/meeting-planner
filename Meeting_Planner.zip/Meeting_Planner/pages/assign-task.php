<?php
/**
 * Assign Task Page (Lavender Theme)
 * Uses PDO database connection
 */

require_once '../includes/config.php';
session_start();

/* ✅ INCLUDE SIDEBAR */
include __DIR__ . '/../includes/sidebar.php';

/* ---------- AUTH CHECK (UNCHANGED) ---------- */
if (!isset($_SESSION['user'])) {
    header("Location: ../index.php");
    exit;
}

$role = strtoupper($_SESSION['user']['role']);

if ($role !== 'ORGANISER') {
    die("Unauthorized access");
}

$assignedBy = $_SESSION['user']['id'];

/* ===============================
   HANDLE FORM SUBMIT (UNCHANGED)
   =============================== */
if (isset($_POST['assign_task'])) {

    $noteId        = $_POST['note_id'];
    $title         = $_POST['title'];
    $desc          = $_POST['description'];
    $progressNotes = $_POST['progress_notes'] ?? null;
    $assignedTo    = $_POST['assigned_to'];
    $department    = $_POST['department'];
    $deadline      = $_POST['deadline'];
    $status        = 'PENDING';
    $filePath      = null;

    if (!empty($_FILES['task_file']['name'])) {
        $folder = __DIR__ . "/../uploads/";
        if (!is_dir($folder)) {
            mkdir($folder, 0777, true);
        }

        $fileName = time() . "_" . basename($_FILES['task_file']['name']);
        move_uploaded_file($_FILES['task_file']['tmp_name'], $folder . $fileName);
        $filePath = "uploads/" . $fileName;
    }

    $sql = "
        INSERT INTO tasks
        (note_id, title, description, progress_notes, assigned_to, assigned_by, department, deadline, status, file_path, created_at)
        VALUES
        (:note_id, :title, :description, :progress_notes, :assigned_to, :assigned_by, :department, :deadline, :status, :file_path, NOW())
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':note_id'        => $noteId,
        ':title'          => $title,
        ':description'    => $desc,
        ':progress_notes' => $progressNotes,
        ':assigned_to'    => $assignedTo,
        ':assigned_by'    => $assignedBy,
        ':department'     => $department,
        ':deadline'       => $deadline,
        ':status'         => $status,
        ':file_path'      => $filePath
    ]);

    echo "<script>alert('✅ Task assigned successfully');</script>";
}

/* ===============================
   FETCH DROPDOWN DATA (UNCHANGED)
   =============================== */
$users = $pdo->query("
    SELECT id, name AS full_name
    FROM users
    WHERE role = 'EMPLOYEE'
")->fetchAll(PDO::FETCH_ASSOC);

$notes = $pdo->query("
    SELECT id, title
    FROM notes
")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Assign Task | Meeting Planner</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>
body {
  font-family: 'Inter', sans-serif;
  background: linear-gradient(135deg, #f1edff, #f7f5ff);
  margin: 0;
}

.page-content {
  margin-left: 260px;
  padding: 50px 40px;
}

.task-container {
  max-width: 1200px;
  margin: auto;
  background: #fff;
  border-radius: 14px;
  box-shadow: 0 8px 24px rgba(123,110,246,0.15);
}

.task-header {
  background: linear-gradient(90deg, #7b6ef6, #a58bff);
  color: white;
  padding: 1.6rem;
  text-align: center;
  border-top-left-radius: 14px;
  border-top-right-radius: 14px;
}

.task-form {
  padding: 30px;
}

.form-label i {
  color: #7b6ef6;
  margin-right: 6px;
}

/* ✅ BUTTON MATCHES HEADER */
.btn-header {
  background: linear-gradient(90deg, #7b6ef6, #a58bff);
  border: none;
  color: #fff;
  font-weight: 600;
  border-radius: 12px;
  transition: all 0.25s ease;
}

.btn-header:hover {
  transform: translateY(-1px);
  box-shadow: 0 6px 18px rgba(123,110,246,0.45);
  background: linear-gradient(90deg, #6a5df0, #9f7cff);
}
</style>
</head>

<body>

<div class="page-content">

  <div class="task-container">

    <div class="task-header">
      <h2><i class="bi bi-check2-square me-2"></i>Assign Task</h2>
      <p class="mb-0">Link a MoM note and assign tasks to employees</p>
    </div>

    <div class="task-form">

      <form method="POST" enctype="multipart/form-data">

        <div class="mb-3">
          <label class="form-label">
            <i class="bi bi-journal-text"></i> Related Note (MoM)
          </label>
          <select name="note_id" class="form-select" required>
            <option value="">-- Select Note --</option>
            <?php foreach ($notes as $n): ?>
              <option value="<?= $n['id'] ?>"><?= htmlspecialchars($n['title']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">
            <i class="bi bi-card-text"></i> Task Title
          </label>
          <input type="text" name="title" class="form-control" required>
        </div>

        <div class="mb-3">
          <label class="form-label">
            <i class="bi bi-file-earmark-text"></i> Task Description
          </label>
          <textarea name="description" class="form-control" rows="3"></textarea>
        </div>

        <div class="mb-3">
          <label class="form-label">
            <i class="bi bi-pencil-square"></i> Progress Notes
          </label>
          <textarea name="progress_notes" class="form-control" rows="3"></textarea>
        </div>

        <div class="mb-3">
          <label class="form-label">
            <i class="bi bi-person-check"></i> Assign To
          </label>
          <select name="assigned_to" class="form-select" required>
            <option value="">-- Select Employee --</option>
            <?php foreach ($users as $u): ?>
              <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['full_name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">
            <i class="bi bi-building"></i> Department
          </label>
          <input type="text" name="department" class="form-control">
        </div>

        <div class="mb-3">
          <label class="form-label">
            <i class="bi bi-calendar-event"></i> Deadline
          </label>
          <input type="datetime-local" name="deadline" class="form-control" required>
        </div>

        <div class="mb-4">
          <label class="form-label">
            <i class="bi bi-paperclip"></i> Attach File (Optional)
          </label>
          <input type="file" name="task_file" class="form-control">
        </div>

        <button type="submit" name="assign_task"
                class="btn btn-header w-100 py-2">
          <i class="bi bi-send me-2"></i>Assign Task
        </button>

      </form>

    </div>
  </div>
</div>

</body>
</html>