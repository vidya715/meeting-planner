<?php
require '../includes/config.php';
session_start();

$conn = $pdo; // use PDO connection

// Fetch meetings
$meetingStmt = $conn->prepare("SELECT id, title, meeting_date FROM meetings");
$meetingStmt->execute();
$meetings = $meetingStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch users
$userStmt = $conn->prepare("SELECT id, name FROM users");
$userStmt->execute();
$users = $userStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Meeting-wise Attendance</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

<style>
/* ===== BODY ===== */
body {
    background: linear-gradient(135deg, #f1edff, #f7f5ff);
    font-family: 'Segoe UI', sans-serif;
    overflow-x: hidden;
}

/* ===== PAGE SHIFT FOR SIDEBAR ===== */
.page-content {
    margin-left: 260px;
    padding: 40px 20px;
}

/* ===== CARD ===== */
.card {
    border-radius: 20px;
    border: none;
    background: #ffffff;
    box-shadow: 0 20px 40px rgba(123,110,246,.18);
}

/* ===== CARD HEADER ===== */
.card-header {
    background: linear-gradient(90deg, #7b6ef6, #a58bff);
    color: #fff;
    font-weight: 600;
    border-radius: 20px 20px 0 0;
}

/* ===== LABELS ===== */
.form-label {
    color: #4c3fbf;
    font-weight: 600;
}

/* ===== SELECT ===== */
.form-select {
    border-radius: 14px;
    background: #f8f6ff;
    border: 2px solid #e4e2f5;
}

/* ===== TABLE ===== */
.table {
    border-radius: 16px;
    overflow: hidden;
    background: #faf9ff;
}

.table thead {
    background: #7b6ef6;
    color: #fff;
}

.table-hover tbody tr:hover td {
    background: rgba(123,110,246, 0.08);
}

/* ===== TOGGLE ===== */
.form-check-input {
    width: 2.6em;
    height: 1.3em;
}

.form-check-input:checked {
    background-color: #7b6ef6;
    border-color: #6a5af9;
}

/* ===== ARRIVAL TIME ===== */
.arrival-time {
    background: #ecebff;
    border-radius: 12px;
}

.arrival-time:enabled {
    background: #e6e4ff;
}

/* ===== SAVE BUTTON ===== */
#saveAttendance {
    background: linear-gradient(90deg, #7b6ef6, #a58bff);
    border: none;
    border-radius: 30px;
    padding: 10px 28px;
    font-weight: 600;
    color: #fff;
    box-shadow: 0 8px 18px rgba(123,110,246,0.45);
}

#saveAttendance:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 26px rgba(123,110,246,0.6);
}
</style>
</head>

<body>

<!-- ✅ SIDEBAR -->
<?php include __DIR__ . '/../includes/sidebar.php'; ?>

<div class="page-content">

<div class="container">
<div class="card">

<div class="card-header d-flex align-items-center">
    <i class="bi bi-calendar-check fs-4 me-2"></i>
    <h5 class="mb-0">Meeting-wise Attendance</h5>
</div>

<div class="card-body">

<div class="mb-4">
    <label class="form-label">
        <i class="bi bi-calendar-event"></i> Select Meeting
    </label>
    <select class="form-select form-select-lg" id="meeting_id">
        <option value="">-- Choose Meeting --</option>
        <?php foreach ($meetings as $m): ?>
        <option value="<?= $m['id'] ?>">
            <?= htmlspecialchars($m['title']) ?> (<?= $m['meeting_date'] ?>)
        </option>
        <?php endforeach; ?>
    </select>
</div>

<div class="table-responsive">
<table class="table table-hover align-middle table-bordered">

<thead class="text-center">
<tr>
    <th>Attendee</th>
    <th>Status</th>
    <th>Arrival Time</th>
</tr>
</thead>

<tbody>
<?php foreach ($users as $u): ?>
<tr>
    <td class="fw-semibold">
        <i class="bi bi-person-circle me-1"></i>
        <?= htmlspecialchars($u['name']) ?>
        <input type="hidden" class="user_id" value="<?= $u['id'] ?>">
    </td>

    <td class="text-center">
        <div class="form-check form-switch d-flex justify-content-center">
            <input class="form-check-input status-toggle" type="checkbox">
        </div>
        <span class="badge bg-secondary mt-1">Absent</span>
    </td>

    <td>
        <input type="time" class="form-control arrival-time" disabled>
    </td>
</tr>
<?php endforeach; ?>
</tbody>

</table>
</div>

<div class="d-flex justify-content-end mt-4">
<button class="btn btn-lg px-4" id="saveAttendance">
    <i class="bi bi-save me-1"></i> Save Attendance
</button>
</div>

<div id="msg" class="mt-3"></div>

</div>
</div>
</div>

</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<script>
$(document).ready(function () {

    $(".status-toggle").change(function () {
        let timeInput = $(this).closest("tr").find(".arrival-time");
        let badge = $(this).closest("td").find(".badge");

        if ($(this).is(":checked")) {
            timeInput.prop("disabled", false);
            let now = new Date().toTimeString().slice(0, 5);
            timeInput.val(now);
            badge.text("Present").removeClass("bg-secondary").addClass("bg-success");
        } else {
            timeInput.prop("disabled", true).val("");
            badge.text("Absent").removeClass("bg-success").addClass("bg-secondary");
        }
    });

    $("#saveAttendance").click(function () {
        let meeting_id = $("#meeting_id").val();
        if (meeting_id === "") return alert("Please select a meeting");

        let attendance = [];
        $("tbody tr").each(function () {
            attendance.push({
                user_id: $(this).find(".user_id").val(),
                status: $(this).find(".status-toggle").is(":checked") ? "Present" : "Absent",
                arrival_time: $(this).find(".arrival-time").val()
            });
        });

        $.ajax({
            url: "../actions/save_attendance.php",
            method: "POST",
            contentType: "application/json",
            data: JSON.stringify({ meeting_id: meeting_id, attendance: attendance }),
            success: function (res) {
                $("#msg").html('<div class="alert alert-success">'+res+'</div>');
            },
            error: function () {
                $("#msg").html('<div class="alert alert-danger">Error saving attendance</div>');
            }
        });
    });
});
</script>

</body>
</html>
